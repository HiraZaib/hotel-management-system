<?php
class PaymentLog {
    public static function logFailedPayment($bookingId, $transactionId, $errorMessage) {
        global $conn;
        $stmt = $conn->prepare("INSERT INTO payment_logs (booking_id, transaction_id, error_message, log_date) VALUES (:booking_id, :transaction_id, :error_message, NOW())");
        $stmt->execute([
            ':booking_id' => $bookingId,
            ':transaction_id' => $transactionId,
            ':error_message' => $errorMessage
        ]);
    }
}