<?php
require_once ROOT_PATH . '/includes/config.php';

class Invoice {
    private $id;
    private $booking_id;
    private $system_user_id;
    private $amount;
    private $status;

    public function __construct($id = null, $booking_id = null, $system_user_id = null, $amount = 0, $status = 'Pending') {
        $this->id = $id;
        $this->booking_id = $booking_id;
        $this->system_user_id = $system_user_id;
        $this->amount = $amount;
        $this->status = $status;
    }

    public static function create($booking_id, $system_user_id, $amount) {
        global $conn;
        $stmt = $conn->prepare("INSERT INTO invoices (booking_id, system_user_id, amount, status) VALUES (:booking_id, :system_user_id, :amount, 'Pending')");
        $stmt->execute([
            ':booking_id' => $booking_id,
            ':system_user_id' => $system_user_id,
            ':amount' => $amount
        ]);
        return $conn->lastInsertId();
    }

    public static function updateStatus($id, $status) {
        global $conn;
        $stmt = $conn->prepare("UPDATE invoices SET status = :status WHERE id = :id");
        $stmt->execute([':status' => $status, ':id' => $id]);
    }

    // Optional getters if needed later
    public function getId() {
        return $this->id;
    }

    public function getBookingId() {
        return $this->booking_id;
    }

    public function getSystemUserId() {
        return $this->system_user_id;
    }

    public function getAmount() {
        return $this->amount;
    }

    public function getStatus() {
        return $this->status;
    }
}
