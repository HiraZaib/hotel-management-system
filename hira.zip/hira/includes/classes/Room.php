<?php
require_once ROOT_PATH . '/includes/config.php';

class Room {
    private $id;
    private $room_number;
    private $type;
    private $price;
    private $status;

    public function __construct($id = null, $room_number = '', $type = '', $price = 0, $status = '') {
        $this->id = $id;
        $this->room_number = $room_number;
        $this->type = $type;
        $this->price = $price;
        $this->status = $status;
    }

    // Getters and Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }
    
    public function getRoomNumber() { return $this->room_number; }
    public function setRoomNumber($room_number) { $this->room_number = $room_number; }
    
    public function getType() { return $this->type; }
    public function setType($type) { $this->type = $type; }
    
    public function getPrice() { return $this->price; }
    public function setPrice($price) { $this->price = $price; }
    
    public function getStatus() { return $this->status; }
    public function setStatus($status) { $this->status = $status; }


    // Static methods for analytics
    public static function getTotalRooms() {
        global $conn;
        $stmt = $conn->query("SELECT COUNT(*) FROM rooms");
        return $stmt->fetchColumn();
    }

    public static function getBookedRooms() {
        global $conn;
        $stmt = $conn->query("SELECT COUNT(*) FROM rooms WHERE status = 'Booked'");
        return $stmt->fetchColumn();
    }

    // Fixed getAll method matching your current database
    public static function getAll() {
        global $conn;
        $stmt = $conn->prepare("SELECT id, room_number, type, price, status FROM rooms ORDER BY room_number");
        $stmt->execute();
        $rooms = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $rooms[] = new self(
                $row['id'],
                $row['room_number'],
                $row['type'],
                $row['price'],
                $row['status']
            );
        }
        return $rooms;
    }

    // Fixed find method
    public static function find($id) {
        global $conn;
        $stmt = $conn->prepare("SELECT id, room_number, type, price, status FROM rooms WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? new self(
            $row['id'],
            $row['room_number'],
            $row['type'],
            $row['price'],
            $row['status']
        ) : null;
    }

    public static function exists($room_number, $exclude_id = null) {
        global $conn;
        $query = "SELECT COUNT(*) FROM rooms WHERE room_number = :room_number";
        $params = ['room_number' => $room_number];
        if ($exclude_id) {
            $query .= " AND id != :id";
            $params['id'] = $exclude_id;
        }
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchColumn() > 0;
    }

    public function save() {
        global $conn;
        try {
            if ($this->id) {
                // Update existing room
                $stmt = $conn->prepare("UPDATE rooms SET room_number = :room_number, type = :type, price = :price, status = :status WHERE id = :id");
                $stmt->execute([
                    ':room_number' => $this->room_number,
                    ':type' => $this->type,
                    ':price' => $this->price,
                    ':status' => $this->status,
                    ':id' => $this->id
                ]);
            } else {
                // Insert new room
                $stmt = $conn->prepare("INSERT INTO rooms (room_number, type, price, status) VALUES (:room_number, :type, :price, :status)");
                $stmt->execute([
                    ':room_number' => $this->room_number,
                    ':type' => $this->type,
                    ':price' => $this->price,
                    ':status' => $this->status
                ]);
                $this->id = $conn->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function delete() {
        global $conn;
        try {
            $stmt = $conn->prepare("DELETE FROM rooms WHERE id = :id");
            $stmt->execute([':id' => $this->id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function hasActiveBookings() {
        global $conn;
        $stmt = $conn->prepare("SELECT COUNT(*) FROM bookings WHERE room_id = :room_id AND status IN ('Confirmed', 'Checked-In')");
        $stmt->execute([':room_id' => $this->id]);
        return $stmt->fetchColumn() > 0;
    }

    public static function getAvailable() {
        global $conn;
        $stmt = $conn->prepare("SELECT id, room_number, type, price, status FROM rooms WHERE status = 'Available'");
        $stmt->execute();
        $rooms = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $rooms[] = new self(
                $row['id'],
                $row['room_number'],
                $row['type'],
                $row['price'],
                $row['status']
            );
        }
        return $rooms;
    }
}