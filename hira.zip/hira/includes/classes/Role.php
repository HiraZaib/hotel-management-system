<?php
require_once ROOT_PATH . '/includes/config.php';

class Role {
    private $id;
    private $name;

    public function __construct($id = null, $name = '') {
        $this->id = $id;
        $this->name = $name;
    }

    // Getters and Setters
    public function getId() { return $this->id; }
    public function getName() { return $this->name; }
    public function setName($name) { $this->name = $name; }

    public function save() {
        try {
            $stmt = $conn->prepare("INSERT INTO role (name) VALUES (:name) ON DUPLICATE KEY UPDATE name = VALUES(name)");
            $stmt->execute([':name' => $this->name]);
            if (!$this->id) $this->id = $conn->lastInsertId();
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    public static function find($id) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM role WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? new self($row['id'], $row['name']) : null;
    }
}