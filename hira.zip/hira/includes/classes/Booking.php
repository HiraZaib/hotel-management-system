<?php
require_once ROOT_PATH . '/includes/config.php';

class Booking {
    private $id;
    private $system_user_id;
    private $email;
    private $username;
    private $book_date;
    private $status;
    private $check_in;
    private $check_out;
    private $room_id;
    private $total_price;
    private $room_number;
    private $room_price;
    private $transaction_id;

    public function __construct($id = null, $system_user_id = null, $email = '', $username = '', $book_date = '', $status = '', $check_in = '', $check_out = '', $room_id = null, $total_price = 0, $room_number = '', $room_price = 0, $transaction_id = null) {
        $this->id = $id;
        $this->system_user_id = $system_user_id;
        $this->email = $email;
        $this->username = $username;
        $this->book_date = $book_date;
        $this->status = $status;
        $this->check_in = $check_in;
        $this->check_out = $check_out;
        $this->room_id = $room_id;
        $this->total_price = $total_price;
        $this->room_number = $room_number;
        $this->room_price = $room_price;
        $this->transaction_id = $transaction_id;
    }

    // Getters
    public function getId() { return $this->id; }
    public function getSystemUserId() { return $this->system_user_id; }
    public function getEmail() { return $this->email; }
    public function getUsername() { return $this->username; }
    public function getCheckIn() { return $this->check_in; }
    public function getCheckOut() { return $this->check_out; }
    public function getTotalPrice() { return $this->total_price; }
    public function getStatus() { return $this->status; }
    public function getRoomNumber() { return $this->room_number; }
    public function getRoomPrice() { return $this->room_price; }
    public function getRoomId() { return $this->room_id; }
    public function getTransactionId() { return $this->transaction_id; }

    // Setters
    public function setCheckIn($check_in) { $this->check_in = $check_in; }
    public function setCheckOut($check_out) { $this->check_out = $check_out; }
    public function setTotalPrice($total_price) { $this->total_price = $total_price; }
    public function setStatus($status) { $this->status = $status; }
    public function setSystemUserId($id) { $this->system_user_id = $id; }
    public function setEmail($email) { $this->email = $email; }
    public function setUsername($username) { $this->username = $username; }
    public function setRoomId($room_id) { $this->room_id = $room_id; }
    public function setRoomNumber($room_number) { $this->room_number = $room_number; }
    public function setRoomPrice($room_price) { $this->room_price = $room_price; }
    public function setTransactionId($transaction_id) { $this->transaction_id = $transaction_id; }

    public static function getBookingsBetween($start, $end) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM bookings WHERE check_in BETWEEN :start AND :end");
        $stmt->execute([':start' => $start, ':end' => $end]);

        $bookings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $booking = new self(
                $row['id'],
                $row['system_user_id'],
                $row['email'],
                $row['username'],
                $row['book_date'],
                $row['status'],
                $row['check_in'],
                $row['check_out'],
                $row['room_id'],
                $row['total_price'],
                $row['room_number'],
                $row['room_price'],
                $row['transaction_id']
            );
            $bookings[] = $booking;
        }
        return $bookings;
    }

    public static function getReport($interval = 'daily') {
        global $conn;
        $groupBy = match ($interval) {
            'daily' => "DATE(check_in)",
            'weekly' => "YEARWEEK(check_in, 1)",
            'monthly' => "DATE_FORMAT(check_in, '%Y-%m')",
            'yearly' => "YEAR(check_in)",
            default => "DATE(check_in)"
        };

        $stmt = $conn->prepare("
            SELECT 
                $groupBy AS period,
                COUNT(*) AS bookings,
                SUM(total_price) AS revenue
            FROM bookings
            WHERE status = 'Confirmed'
            GROUP BY period
            ORDER BY period DESC
            LIMIT 12
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getBookingsBySystemUserId($system_user_id) {
        global $conn;
        $stmt = $conn->prepare("SELECT b.*, r.room_number, r.price as room_price 
                                FROM bookings b
                                JOIN rooms r ON b.room_id = r.id
                                WHERE b.system_user_id = :id
                                ORDER BY b.check_in DESC");
        $stmt->execute([':id' => $system_user_id]);

        $bookings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $booking = new Booking(
                $row['id'],
                $row['system_user_id'],
                $row['email'],
                $row['username'],
                $row['book_date'],
                $row['status'],
                $row['check_in'],
                $row['check_out'],
                $row['room_id'],
                $row['total_price'],
                $row['room_number'],
                $row['room_price'],
                $row['transaction_id']
            );
            $bookings[] = $booking;
        }
        return $bookings;
    }

    public function save() {
        global $conn;
        try {
            if ($this->id) {
                $stmt = $conn->prepare("UPDATE bookings 
                                        SET check_in = :check_in, 
                                            check_out = :check_out, 
                                            total_price = :total_price, 
                                            status = :status,
                                            room_number = :room_number,
                                            room_price = :room_price,
                                            transaction_id = :transaction_id
                                        WHERE id = :id");
                return $stmt->execute([
                    ':check_in' => $this->check_in,
                    ':check_out' => $this->check_out,
                    ':total_price' => $this->total_price,
                    ':status' => $this->status,
                    ':room_number' => $this->room_number,
                    ':room_price' => $this->room_price,
                    ':transaction_id' => $this->transaction_id,
                    ':id' => $this->id
                ]);
            } else {
                $stmt = $conn->prepare("INSERT INTO bookings 
                    (system_user_id, room_id, check_in, check_out, total_price, status, book_date, email, username, room_number, room_price, transaction_id) 
                    VALUES 
                    (:system_user_id, :room_id, :check_in, :check_out, :total_price, :status, NOW(), :email, :username, :room_number, :room_price, :transaction_id)");
                
                $result = $stmt->execute([
                    ':system_user_id' => $this->system_user_id,
                    ':room_id' => $this->room_id,
                    ':check_in' => $this->check_in,
                    ':check_out' => $this->check_out,
                    ':total_price' => $this->total_price,
                    ':status' => $this->status,
                    ':email' => $this->email,
                    ':username' => $this->username,
                    ':room_number' => $this->room_number,
                    ':room_price' => $this->room_price,
                    ':transaction_id' => $this->transaction_id
                ]);

                if ($result) {
                    $this->id = $conn->lastInsertId();
                }
                return $result;
            }
        } catch (PDOException $e) {
            error_log("Booking save error: " . $e->getMessage());
            return false;
        }
    }

    public static function findByIdAndUserId($booking_id, $user_id) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM bookings WHERE id = :id AND system_user_id = :uid LIMIT 1");
        $stmt->execute([
            ':id' => $booking_id,
            ':uid' => $user_id
        ]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $booking = new self(
                $row['id'],
                $row['system_user_id'],
                $row['email'],
                $row['username'],
                $row['book_date'],
                $row['status'],
                $row['check_in'],
                $row['check_out'],
                $row['room_id'],
                $row['total_price'],
                $row['room_number'],
                $row['room_price'],
                $row['transaction_id']
            );
            return $booking;
        }
        return null;
    }

    public static function find($id) {
        global $conn;
        $stmt = $conn->prepare("SELECT b.*, r.room_number, r.price as room_price 
                                FROM bookings b 
                                JOIN rooms r ON b.room_id = r.id 
                                WHERE b.id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $booking = new self(
                $row['id'],
                $row['system_user_id'],
                $row['email'],
                $row['username'],
                $row['book_date'],
                $row['status'],
                $row['check_in'],
                $row['check_out'],
                $row['room_id'],
                $row['total_price'],
                $row['room_number'],
                $row['room_price'],
                $row['transaction_id']
            );
            return $booking;
        }
        return null;
    }

    public static function getRecent($limit = 10) {
        global $conn;
        $stmt = $conn->prepare("SELECT b.id, b.check_in, b.check_out, b.status, b.total_price, 
                                       r.room_number, r.price AS room_price,
                                       b.username, b.transaction_id
                                FROM bookings b 
                                JOIN rooms r ON b.room_id = r.id 
                                ORDER BY b.id DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        $bookings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $booking = new self(
                $row['id'],
                null, // system_user_id not needed here
                '',
                $row['username'],
                '',
                $row['status'],
                $row['check_in'],
                $row['check_out'],
                null,
                $row['total_price'],
                $row['room_number'],
                $row['room_price'],
                $row['transaction_id']
            );
            $bookings[] = $booking;
        }
        return $bookings;
    }

    public static function searchByUsernameOrId($search_term) {
        global $conn;
        $stmt = $conn->prepare("SELECT b.id, b.check_in, b.check_out, b.status, b.username, r.room_number, b.transaction_id
                                FROM bookings b 
                                JOIN rooms r ON b.room_id = r.id 
                                WHERE b.username LIKE :term OR b.id = :id");
        $search_param = "%$search_term%";
        $stmt->execute([
            ':term' => $search_param,
            ':id' => is_numeric($search_term) ? $search_term : 0
        ]);
        
        $results = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $booking = new self(
                $row['id'],
                null,
                '',
                $row['username'],
                '',
                $row['status'],
                $row['check_in'],
                $row['check_out'],
                null,
                0, // total_price not fetched here
                $row['room_number'],
                0, // room_price not fetched here
                $row['transaction_id']
            );
            $results[] = $booking;
        }
        return $results;
    }

    public static function isRoomAvailable($room_id, $check_in, $check_out) {
        global $conn;
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM bookings 
                                    WHERE room_id = :room_id 
                                    AND status IN ('Confirmed', 'Checked-In')
                                    AND (
                                        (check_in <= :check_in AND check_out > :check_in) OR
                                        (check_in < :check_out AND check_out >= :check_out) OR
                                        (check_in >= :check_in AND check_out <= :check_out)
                                    )");
            $stmt->execute([
                ':room_id' => $room_id,
                ':check_in' => $check_in,
                ':check_out' => $check_out
            ]);
            return $stmt->fetchColumn() == 0;
        } catch (PDOException $e) {
            error_log("Error checking room availability: " . $e->getMessage());
            return false;
        }
    }
}