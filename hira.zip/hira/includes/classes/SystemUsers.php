<?php
require_once ROOT_PATH . '/includes/config.php';

class SystemUsers {
    private $id;
    private $role_id;
    private $username;
    private $password;
    private $email;


      public function __construct($id = null, $role_id = null, $username = '', $password = '', $email = '') {
        $this->id = $id;
        $this->role_id = $role_id;
        $this->username = $username;
        $this->password = $password;
        $this->email = $email;
    }

    public function getId() { return $this->id; }
    public function getUsername() { return $this->username; }

    public function getPassword() { return $this->password; }
    public function getEmail() { return $this->email; }
    public function setRole($role) { 
        // Assuming role_id maps to a role name; adjust if stored directly
        global $conn;
        $stmt = $conn->prepare("SELECT id FROM role WHERE name = :role");
        $stmt->execute([':role' => $role]);
        $role_id = $stmt->fetchColumn();
        $this->role_id = $role_id ?: null; // Default to null if not found
    }
    // Add other getters/setters as needed

    public static function findByUsername($username) {
        global $conn;
        $stmt = $conn->prepare("SELECT id, role_id,  username, password, email 
                                FROM system_users 
                                WHERE username = :username");
        $stmt->execute([':username' => $username]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? new self($row['id'], $row['role_id'], $row['username'], $row['password'], $row['email']) : null;
    }

    public static function usernameExists($username) {
        global $conn;
        $stmt = $conn->prepare("SELECT COUNT(*) FROM system_users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        return $stmt->fetchColumn() > 0;
    }

    public static function emailExists($email) {
        global $conn;
        $stmt = $conn->prepare("SELECT COUNT(*) FROM system_users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        return $stmt->fetchColumn() > 0;
    }

    public function save() {
        global $conn;
        try {
            if ($this->id) {
                // Update existing user (not applicable for registration)
                $stmt = $conn->prepare("UPDATE system_users SET username = :username, email = :email, password = :password, role_id = :role_id WHERE id = :id");
                $stmt->execute([
                    ':username' => $this->username,
                    ':email' => $this->email,
                    ':password' => $this->password,
                    ':role_id' => $this->role_id,
                    ':id' => $this->id
                ]);
            } else {
                // Insert new user
                $stmt = $conn->prepare("INSERT INTO system_users (username, email, password, role_id) VALUES (:username, :email, :password, :role_id)");
                $stmt->execute([
                    ':username' => $this->username,
                    ':email' => $this->email,
                    ':password' => $this->password,
                    ':role_id' => $this->role_id
                ]);
                $this->id = $conn->lastInsertId();
            }
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    public function getRole() { 
        // Assuming role_id maps to a role name via a role table; adjust if stored directly
        global $conn;
        $stmt = $conn->prepare("SELECT name FROM role WHERE id = :role_id");
        $stmt->execute([':role_id' => $this->role_id]);
        return $stmt->fetchColumn() ?: 'Guest'; // Default to Guest if not found
    }
    // Add other getters/setters as needed

   
    
    public static function find($id) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM system_users WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? new self($row['id'], $row['role_id'], $row['username'], $row['password'], $row['email'], ) : null;
    }


    public static function getTotalStaff() {
        global $conn;
        $stmt = $conn->query("SELECT COUNT(*) FROM system_users WHERE role_id = (SELECT id FROM role WHERE name = 'Staff')");
        return $stmt->fetchColumn();
    }

    public static function getAllStaff() {
        global $conn;
        $stmt = $conn->prepare("SELECT id, role_id, username, email, password FROM system_users WHERE role_id = (SELECT id FROM role WHERE name = 'Staff')");
        $stmt->execute();
        $staff = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
$staff[] = new self(
            $row['id'],
            $row['role_id'],
            $row['username'],
            '', // password not needed here
            $row['email']
        );        }
        return $staff;
    }
    public static function findByEmail($email) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM system_users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? new self($row['id'], $row['role_id'], $row['username'], $row['password'], $row['email']) : null;
}

public function setPassword($hashedPassword) {
    $this->password = $hashedPassword;
}

}