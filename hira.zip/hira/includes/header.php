<?php
// Ensure session is started (moved from index.php if needed)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Hotel Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
   

</head>
<body>
    <header class="main-header">
        <div class="header-bg-overlay"></div>
        <div class="header-container">
            <div class="logo-section">
                <a href="<?php echo BASE_URL; ?>index.php" class="logo-wrapper">
                    <img src="/hira/assets/logo.jpg" alt="HA Aura Logo" class="logo">
                    <div class="logo-glow"></div>
                </a>
                <a href="<?php echo BASE_URL; ?>index.php" class="hotel-info">
                    <h1 class="brand-name">HA Aura</h1>
                    <p class="welcome-message">
                        <i class="fas fa-star"></i>
                        Experience Luxury & Excellence
                        <i class="fas fa-star"></i>
                    </p>
                </a>
            </div>
            
            <nav class="main-nav">
                <div class="nav-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                
                <div class="nav-menu">
                    <?php if (isset($_SESSION['role'])): ?>
                        <a href="<?php echo BASE_URL; ?>pages/edit.php" class="user-welcome">
    <div class="user-avatar">
        <i class="fas fa-user-circle"></i>
    </div>
    <div class="user-info">
        <span class="username"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        <span class="user-role"><?php echo htmlspecialchars($_SESSION['role']); ?></span>
    </div>
</a>

                        
                        <div class="nav-links">
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Guest'): ?>
        <a href="<?php echo BASE_URL; ?>pages/guest_dashboard.php" class="nav-link">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/book_room.php" class="nav-link">
            <i class="fas fa-bed"></i>
            <span>Book Room</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/logout.php" class="nav-link logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'Staff'): ?>
        <a href="<?php echo BASE_URL; ?>pages/staff_dashboard.php" class="nav-link">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/check_in.php" class="nav-link">
            <i class="fas fa-calendar-check"></i>
            <span>Check-In</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/check_out.php" class="nav-link">
            <i class="fas fa-calendar-times"></i>
            <span>Check-Out</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/logout.php" class="nav-link logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'Admin'): ?>
        <a href="<?php echo BASE_URL; ?>pages/admin_dashboard.php" class="nav-link">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/manage_rooms.php" class="nav-link">
            <i class="fas fa-cogs"></i>
            <span>Manage Rooms</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/logout.php" class="nav-link logout">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    <?php endif; ?>
</div>
<?php else: ?>
    <div class="auth-links">
        <a href="<?php echo BASE_URL; ?>pages/login.php" class="nav-link login-btn">
            <i class="fas fa-sign-in-alt"></i>
            <span>Login</span>
        </a>
        <a href="<?php echo BASE_URL; ?>pages/register.php" class="nav-link register-btn">
            <i class="fas fa-user-plus"></i>
            <span>Register</span>
        </a>
    </div>
<?php endif; ?>
                </div>
            </nav>
        </div>
        
        <div class="header-particles">
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
        </div>
    </header>
     <script>
  document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.querySelector('.nav-toggle');
    const menu = document.querySelector('.nav-menu');

    toggle.addEventListener('click', function () {
      menu.classList.toggle('active');
    });
  });
</script>
</body>