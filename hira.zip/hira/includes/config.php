<?php
define('ROOT_PATH', dirname(__DIR__)); // Defines the root as the parent directory of includes
define('BASE_URL', '/hira/'); // Adjust as needed
$host = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_management";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Include Stripe PHP library
require_once ROOT_PATH . '/vendor/autoload.php';

// Set Stripe API key
\Stripe\Stripe::setApiKey('pk_test_51RVE9rITbMHz7SKKFGjEYAKNW54fORMF1dmEhfXN4EosTMCwtC9LUAYwQnWxVSagCQsjjUjvLgNcLOzRzNevbnxH006uEJDTG8'); 

?>

