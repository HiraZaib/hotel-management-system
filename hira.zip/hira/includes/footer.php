<?php
date_default_timezone_set('Asia/Karachi'); // Set to Pakistan time zone
$currentYear = date('Y');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Hotel Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <footer>
    <div class="footer-container">
        <div class="footer-content">
            <div class="contact-info">
                <h3><i class="fas fa-map-marker-alt"></i> Contact Us</h3>
                <div class="contact-item">
                    <i class="fas fa-university"></i>
                    <span>University of the Punjab, Gujranwala Campus, Pakistan</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <span>+92-320-7949729</span>
                </div>
                <div class="contact-item">
                    <i class="fas fa-envelope"></i>
                    <span>hirazaib939@gmail.com</span>
                </div>
            </div>
            
            <div class="social-media">
                <h3><i class="fas fa-share-alt"></i> Follow Us</h3>
                <div class="social-links">
                    <a href="https://www.facebook.com/jaffar.tayyar.5682" target="_blank" class="social-btn facebook">
                        <i class="fab fa-facebook-f"></i>
                        <span>Facebook</span>
                    </a>
                    <a href="https://x.com/HeerA54190?s=09" target="_blank" class="social-btn twitter">
                        <i class="fab fa-twitter"></i>
                        <span>X (Twitter)</span>
                    </a>
                    <a href="https://www.instagram.com/heer.a_k?igsh=MTdxajl1ZW90YXNm" target="_blank" class="social-btn instagram">
                        <i class="fab fa-instagram"></i>
                        <span>Instagram</span>
                    </a>
                </div>
            </div>
            
            <div class="company-info">
                <h3><i class="fas fa-building"></i> HA Aura</h3>
                <p>Empowering hotels with smart management solutions for enhanced guest experiences and operational excellence.</p>
                <div class="footer-logo">
                    <img src="/hira/assets/logo.jpg" alt="HA Aura Logo" class="footer-logo-img">
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="copyright">
                <p>&copy; <?php echo $currentYear; ?> HA Aura. All rights reserved.</p>
                <p class="developers">Developed with <i class="fas fa-heart"></i> by <strong>Hira Zaib, Ayesha Nasir & Ayesha Liaqat</strong></p>
            </div>
        </div>
    </div>
</footer>
</body>
</html>