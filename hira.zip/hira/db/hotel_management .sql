-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2025 at 12:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `book_date` datetime DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `check_in` date DEFAULT NULL,
  `check_out` date DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `room_number` varchar(10) DEFAULT NULL,
  `room_price` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `system_user_id` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `book_date`, `status`, `check_in`, `check_out`, `room_id`, `total_price`, `room_number`, `room_price`, `created_at`, `system_user_id`, `email`, `username`, `transaction_id`) VALUES
(37, '2025-07-02 18:48:32', 'Checked-Out', '2025-07-02', '2025-07-03', 13, 5000.00, '01', 5000.00, '2025-07-02 13:48:32', 23, 'hirazaib@gmail.com', 'hira', 'pi_3RgR7wITbMHz7SKK1oPP5XI5'),
(38, '2025-07-02 19:06:53', 'Checked-Out', '2025-07-02', '2025-07-03', 13, 6000.00, '02', 6000.00, '2025-07-02 14:06:53', 26, 'ayesha1@gmail.com', 'ayesha1', 'pi_3RgSK3ITbMHz7SKK0aqXKaCa'),
(39, '2025-07-02 19:07:16', 'Checked-Out', '2025-07-02', '2025-07-03', 13, 6000.00, '02', 6000.00, '2025-07-02 14:07:16', 26, 'ayesha1@gmail.com', 'ayesha1', 'pi_3RgSMKITbMHz7SKK1nK1iubj'),
(40, '2025-07-02 19:17:17', 'Checked-Out', '2025-07-05', '2025-07-07', 14, 10000.00, '03', 5000.00, '2025-07-02 14:17:17', 27, 'ayesha2@gmail.com', 'ayesha2', 'pi_3RgSQYITbMHz7SKK1jfjcMSS'),
(41, '2025-07-02 19:21:23', 'Checked-Out', '2025-07-02', '2025-07-03', 15, 7000.00, '04', 7000.00, '2025-07-02 14:21:23', 28, 'areeba@gmail.com', 'areeba', 'pi_3RgSROITbMHz7SKK0lWjkh1A'),
(42, '2025-07-02 19:27:41', 'Checked-Out', '2025-07-08', '2025-07-09', 16, 2000.00, '05', 2000.00, '2025-07-02 14:27:41', 29, 'nabeel@gmail.com', 'nabeel', 'pi_3RgSTAITbMHz7SKK0WBeuK5G'),
(43, '2025-07-02 19:31:33', 'Checked-In', '2025-07-02', '2025-07-03', 16, 2000.00, '05', 2000.00, '2025-07-02 14:31:33', 30, 'muavia@gmail.com', 'muavia', NULL),
(44, '2025-07-02 19:40:01', 'Checked-Out', '2025-07-02', '2025-07-03', 17, 8000.00, '27', 8000.00, '2025-07-02 14:40:01', 31, 'moaviaa856@gamil.com', 'ammar', 'pi_3Rgi25ITbMHz7SKK0DBVvSJ4'),
(45, '2025-07-02 19:51:55', 'Checked-Out', '2025-07-02', '2025-07-03', 19, 5000.00, '41', 5000.00, '2025-07-02 14:51:55', 33, 'moaviaa856@gamil.com', 'hirazaib', 'pi_3RgTOlITbMHz7SKK1gMSueGi'),
(46, '2025-07-02 20:00:31', 'Pending', '2025-07-02', '2025-07-03', 20, 5000.00, '33', 5000.00, '2025-07-02 15:00:31', 34, 'hirazaib939@gmail.com', 'saba', NULL),
(47, '2025-07-02 20:05:39', 'Confirmed', '2025-07-02', '2025-07-03', 20, 5000.00, '33', 5000.00, '2025-07-02 15:05:39', 35, 'moaviaa856@gmail.com', 'anam', NULL),
(48, '2025-07-02 21:18:32', 'Checked-Out', '2025-07-02', '2025-07-03', 24, 5000.00, '20', 5000.00, '2025-07-02 16:18:32', 39, 'david@gmail.com', 'david', 'pi_3Rgi4WITbMHz7SKK1tPgvpqM'),
(49, '2025-07-02 21:44:16', 'Checked-Out', '2025-07-05', '2025-07-07', 25, 12000.00, '17', 6000.00, '2025-07-02 16:44:16', 40, 'smith@gmail.com', 'smith', 'pi_3Rgi38ITbMHz7SKK1xL5WyvR'),
(50, '2025-07-03 12:40:17', 'Checked-Out', '2025-08-03', '2025-08-04', 16, 2000.00, '05', 2000.00, '2025-07-03 07:40:17', 41, 'linda1234@gmail.com', 'linda', 'pi_3RghoUITbMHz7SKK1dLf5tcP'),
(51, '2025-07-03 13:05:07', 'Checked-Out', '2025-07-03', '2025-07-04', 26, 3000.00, '16', 3000.00, '2025-07-03 08:05:07', 43, 'imamjaffar76@gmail.com', 'imamjaffar76', 'pi_3Rgi9mITbMHz7SKK1wtdyrcH'),
(52, '2025-07-03 14:00:00', 'Checked-In', '2025-07-05', '2025-07-07', 14, 5000.00, '03', 5000.00, '2025-07-03 10:01:22', 27, 'zara123@gmail.com', 'zara123', 'pi_001'),
(53, '2025-07-03 14:05:00', 'Checked-Out', '2025-07-06', '2025-07-07', 15, 7000.00, '04', 7000.00, '2025-07-03 10:01:22', 28, 'danish@gmail.com', 'danish', 'pi_002'),
(54, '2025-07-03 14:10:00', 'Confirmed', '2025-07-07', '2025-07-09', 16, 2000.00, '05', 2000.00, '2025-07-03 10:01:22', 29, 'maria123@gmail.com', 'maria123', 'pi_003'),
(55, '2025-07-03 14:15:00', 'Pending', '2025-07-05', '2025-07-06', 17, 8000.00, '27', 8000.00, '2025-07-03 10:01:22', 30, 'kamran@gmail.com', 'kamran', NULL),
(56, '2025-07-03 14:20:00', 'Checked-In', '2025-07-04', '2025-07-05', 18, 5000.00, '37', 5000.00, '2025-07-03 10:01:22', 33, 'amna456@gmail.com', 'amna456', 'pi_004'),
(57, '2025-07-03 14:25:00', 'Checked-Out', '2025-07-08', '2025-07-10', 19, 5000.00, '41', 5000.00, '2025-07-03 10:01:22', 34, 'fahad321@gmail.com', 'fahad321', 'pi_005'),
(58, '2025-07-03 14:30:00', 'Confirmed', '2025-07-03', '2025-07-04', 20, 5000.00, '33', 5000.00, '2025-07-03 10:01:22', 35, 'soha789@gmail.com', 'soha789', 'pi_006'),
(59, '2025-07-03 14:35:00', 'Checked-In', '2025-07-06', '2025-07-07', 24, 5000.00, '20', 5000.00, '2025-07-03 10:01:22', 39, 'talha987@gmail.com', 'talha987', NULL),
(60, '2025-07-03 14:40:00', 'Checked-Out', '2025-07-10', '2025-07-11', 25, 6000.00, '17', 6000.00, '2025-07-03 10:01:22', 40, 'hina777@gmail.com', 'hina777', 'pi_007'),
(61, '2025-07-03 14:45:00', 'Checked-In', '2025-07-05', '2025-07-06', 26, 3000.00, '16', 3000.00, '2025-07-03 10:01:22', 41, 'usman123@gmail.com', 'usman123', 'pi_008'),
(62, '2025-07-03 14:50:00', 'Pending', '2025-07-03', '2025-07-04', 14, 5000.00, '03', 5000.00, '2025-07-03 10:01:22', 27, 'fatima786@gmail.com', 'fatima786', NULL),
(63, '2025-07-03 14:55:00', 'Checked-Out', '2025-07-06', '2025-07-08', 15, 7000.00, '04', 7000.00, '2025-07-03 10:01:22', 28, 'raheel@gmail.com', 'raheel', 'pi_009'),
(64, '2025-07-03 15:00:00', 'Confirmed', '2025-07-07', '2025-07-09', 16, 2000.00, '05', 2000.00, '2025-07-03 10:01:22', 29, 'hassan23@gmail.com', 'hassan23', 'pi_010'),
(65, '2025-07-03 15:05:00', 'Checked-In', '2025-07-03', '2025-07-05', 17, 8000.00, '27', 8000.00, '2025-07-03 10:01:22', 30, 'amna007@gmail.com', 'amna007', 'pi_011'),
(66, '2025-07-03 15:10:00', 'Checked-Out', '2025-07-08', '2025-07-09', 18, 5000.00, '37', 5000.00, '2025-07-03 10:01:22', 33, 'asad.khan@gmail.com', 'asadkhan', 'pi_012'),
(67, '2025-07-03 15:15:00', 'Confirmed', '2025-07-04', '2025-07-05', 19, 5000.00, '41', 5000.00, '2025-07-03 10:01:22', 34, 'mehak123@gmail.com', 'mehak123', 'pi_013'),
(68, '2025-07-03 15:20:00', 'Pending', '2025-07-05', '2025-07-06', 20, 5000.00, '33', 5000.00, '2025-07-03 10:01:22', 35, 'hira999@gmail.com', 'hira999', NULL),
(69, '2025-07-03 15:25:00', 'Checked-In', '2025-07-03', '2025-07-04', 24, 5000.00, '20', 5000.00, '2025-07-03 10:01:22', 39, 'salman786@gmail.com', 'salman786', 'pi_014'),
(70, '2025-07-03 15:30:00', 'Checked-Out', '2025-07-08', '2025-07-09', 25, 6000.00, '17', 6000.00, '2025-07-03 10:01:22', 40, 'warda123@gmail.com', 'warda123', 'pi_015'),
(71, '2025-07-03 15:35:00', 'Confirmed', '2025-07-07', '2025-07-08', 26, 3000.00, '16', 3000.00, '2025-07-03 10:01:22', 41, 'ayman123@gmail.com', 'ayman123', 'pi_016'),
(72, '2025-07-03 15:40:00', 'Checked-In', '2025-07-04', '2025-07-05', 14, 5000.00, '03', 5000.00, '2025-07-03 10:01:22', 27, 'sajid22@gmail.com', 'sajid22', NULL),
(73, '2025-07-03 15:45:00', 'Checked-Out', '2025-07-06', '2025-07-08', 15, 7000.00, '04', 7000.00, '2025-07-03 10:01:22', 28, 'hafsa333@gmail.com', 'hafsa333', 'pi_017'),
(74, '2025-07-03 15:50:00', 'Pending', '2025-07-05', '2025-07-06', 16, 2000.00, '05', 2000.00, '2025-07-03 10:01:22', 29, 'rehan007@gmail.com', 'rehan007', 'pi_018'),
(75, '2025-07-03 15:55:00', 'Checked-In', '2025-07-04', '2025-07-06', 17, 8000.00, '27', 8000.00, '2025-07-03 10:01:22', 30, 'inaya123@gmail.com', 'inaya123', 'pi_019'),
(76, '2025-07-03 16:00:00', 'Checked-Out', '2025-07-08', '2025-07-09', 18, 5000.00, '37', 5000.00, '2025-07-03 10:01:22', 33, 'burhan@gmail.com', 'burhan', 'pi_020'),
(77, '2025-07-03 14:00:00', 'Checked-In', '2025-07-05', '2025-07-07', 14, 5000.00, '03', 5000.00, '2025-07-03 10:02:42', 27, 'zara123@gmail.com', 'zara123', 'pi_001'),
(78, '2025-07-03 14:05:00', 'Checked-Out', '2025-07-06', '2025-07-07', 15, 7000.00, '04', 7000.00, '2025-07-03 10:02:42', 28, 'danish@gmail.com', 'danish', 'pi_002'),
(79, '2025-07-03 14:10:00', 'Confirmed', '2025-07-07', '2025-07-09', 16, 2000.00, '05', 2000.00, '2025-07-03 10:02:42', 29, 'maria123@gmail.com', 'maria123', 'pi_003'),
(80, '2025-07-03 14:15:00', 'Pending', '2025-07-05', '2025-07-06', 17, 8000.00, '27', 8000.00, '2025-07-03 10:02:42', 30, 'kamran@gmail.com', 'kamran', NULL),
(81, '2025-07-03 14:20:00', 'Checked-In', '2025-07-04', '2025-07-05', 18, 5000.00, '37', 5000.00, '2025-07-03 10:02:42', 33, 'amna456@gmail.com', 'amna456', 'pi_004'),
(82, '2025-07-03 14:25:00', 'Checked-Out', '2025-07-08', '2025-07-10', 19, 5000.00, '41', 5000.00, '2025-07-03 10:02:42', 34, 'fahad321@gmail.com', 'fahad321', 'pi_005'),
(83, '2025-07-03 14:30:00', 'Confirmed', '2025-07-03', '2025-07-04', 20, 5000.00, '33', 5000.00, '2025-07-03 10:02:42', 35, 'soha789@gmail.com', 'soha789', 'pi_006'),
(84, '2025-07-03 14:35:00', 'Checked-In', '2025-07-06', '2025-07-07', 24, 5000.00, '20', 5000.00, '2025-07-03 10:02:42', 39, 'talha987@gmail.com', 'talha987', NULL),
(85, '2025-07-03 14:40:00', 'Checked-Out', '2025-07-10', '2025-07-11', 25, 6000.00, '17', 6000.00, '2025-07-03 10:02:42', 40, 'hina777@gmail.com', 'hina777', 'pi_007'),
(86, '2025-07-03 14:45:00', 'Checked-In', '2025-07-05', '2025-07-06', 26, 3000.00, '16', 3000.00, '2025-07-03 10:02:42', 41, 'usman123@gmail.com', 'usman123', 'pi_008'),
(87, '2025-07-03 14:50:00', 'Pending', '2025-07-03', '2025-07-04', 14, 5000.00, '03', 5000.00, '2025-07-03 10:02:42', 27, 'fatima786@gmail.com', 'fatima786', NULL),
(88, '2025-07-03 14:55:00', 'Checked-Out', '2025-07-06', '2025-07-08', 15, 7000.00, '04', 7000.00, '2025-07-03 10:02:42', 28, 'raheel@gmail.com', 'raheel', 'pi_009'),
(89, '2025-07-03 15:00:00', 'Confirmed', '2025-07-07', '2025-07-09', 16, 2000.00, '05', 2000.00, '2025-07-03 10:02:42', 29, 'hassan23@gmail.com', 'hassan23', 'pi_010'),
(90, '2025-07-03 15:05:00', 'Checked-In', '2025-07-03', '2025-07-05', 17, 8000.00, '27', 8000.00, '2025-07-03 10:02:42', 30, 'amna007@gmail.com', 'amna007', 'pi_011'),
(91, '2025-07-03 15:10:00', 'Checked-Out', '2025-07-08', '2025-07-09', 18, 5000.00, '37', 5000.00, '2025-07-03 10:02:42', 33, 'asad.khan@gmail.com', 'asadkhan', 'pi_012'),
(92, '2025-07-03 15:15:00', 'Confirmed', '2025-07-04', '2025-07-05', 19, 5000.00, '41', 5000.00, '2025-07-03 10:02:42', 34, 'mehak123@gmail.com', 'mehak123', 'pi_013'),
(93, '2025-07-03 15:20:00', 'Pending', '2025-07-05', '2025-07-06', 20, 5000.00, '33', 5000.00, '2025-07-03 10:02:42', 35, 'hira999@gmail.com', 'hira999', NULL),
(94, '2025-07-03 15:25:00', 'Checked-In', '2025-07-03', '2025-07-04', 24, 5000.00, '20', 5000.00, '2025-07-03 10:02:42', 39, 'salman786@gmail.com', 'salman786', 'pi_014'),
(95, '2025-07-03 15:30:00', 'Checked-Out', '2025-07-08', '2025-07-09', 25, 6000.00, '17', 6000.00, '2025-07-03 10:02:42', 40, 'warda123@gmail.com', 'warda123', 'pi_015'),
(96, '2025-07-03 15:35:00', 'Confirmed', '2025-07-07', '2025-07-08', 26, 3000.00, '16', 3000.00, '2025-07-03 10:02:42', 41, 'ayman123@gmail.com', 'ayman123', 'pi_016'),
(97, '2025-07-03 15:40:00', 'Checked-In', '2025-07-04', '2025-07-05', 14, 5000.00, '03', 5000.00, '2025-07-03 10:02:42', 27, 'sajid22@gmail.com', 'sajid22', NULL),
(98, '2025-07-03 15:45:00', 'Checked-Out', '2025-07-06', '2025-07-08', 15, 7000.00, '04', 7000.00, '2025-07-03 10:02:42', 28, 'hafsa333@gmail.com', 'hafsa333', 'pi_017'),
(99, '2025-07-03 15:50:00', 'Pending', '2025-07-05', '2025-07-06', 16, 2000.00, '05', 2000.00, '2025-07-03 10:02:42', 29, 'rehan007@gmail.com', 'rehan007', 'pi_018'),
(100, '2025-07-03 15:55:00', 'Checked-In', '2025-07-04', '2025-07-06', 17, 8000.00, '27', 8000.00, '2025-07-03 10:02:42', 30, 'inaya123@gmail.com', 'inaya123', 'pi_019'),
(101, '2025-07-03 16:00:00', 'Checked-Out', '2025-07-08', '2025-07-09', 18, 5000.00, '37', 5000.00, '2025-07-03 10:02:42', 33, 'burhan@gmail.com', 'burhan', 'pi_020');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `system_user_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `booking_id`, `system_user_id`, `amount`, `status`) VALUES
(46, 33, 18, 1000.00, 'Paid'),
(47, 37, 23, 5000.00, 'Paid'),
(48, 38, 26, 6000.00, 'Paid'),
(49, 39, 26, 6000.00, 'Paid'),
(50, 40, 27, 10000.00, 'Paid'),
(51, 41, 28, 7000.00, 'Paid'),
(52, 42, 29, 2000.00, 'Paid'),
(53, 45, 33, 5000.00, 'Paid'),
(54, 50, 41, 2000.00, 'Paid'),
(55, 44, 31, 8000.00, 'Paid'),
(56, 49, 40, 12000.00, 'Paid'),
(57, 48, 39, 5000.00, 'Paid'),
(58, 51, 43, 3000.00, 'Paid'),
(59, 52, 44, 5000.00, 'Paid'),
(60, 53, 45, 7000.00, 'Paid'),
(61, 54, 46, 2000.00, 'Paid'),
(62, 55, 47, 8000.00, 'Paid'),
(63, 56, 48, 5000.00, 'Paid'),
(64, 57, 49, 5000.00, 'Paid'),
(65, 58, 50, 5000.00, 'Paid'),
(66, 59, 51, 5000.00, 'Paid'),
(67, 60, 52, 6000.00, 'Paid'),
(68, 61, 53, 3000.00, 'Paid'),
(69, 62, 54, 5000.00, 'Paid'),
(70, 63, 55, 7000.00, 'Paid'),
(71, 64, 56, 2000.00, 'Paid'),
(72, 65, 57, 8000.00, 'Paid'),
(73, 66, 58, 5000.00, 'Paid'),
(74, 67, 59, 5000.00, 'Paid'),
(75, 68, 60, 5000.00, 'Paid'),
(76, 69, 61, 5000.00, 'Paid'),
(77, 70, 62, 6000.00, 'Paid'),
(78, 71, 63, 3000.00, 'Paid'),
(79, 72, 64, 5000.00, 'Paid'),
(80, 73, 65, 7000.00, 'Paid'),
(81, 74, 66, 2000.00, 'Paid'),
(82, 75, 67, 8000.00, 'Paid'),
(83, 76, 68, 5000.00, 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `code`, `expires_at`) VALUES
('sajid22@gmail.com', '5978', '2025-07-03 19:30:00'),
('hafsa333@gmail.com', '7910', '2025-07-03 19:32:00'),
('burhan@gmail.com', '8776', '2025-07-03 19:34:00'),
('inaya123@gmail.com', '6078', '2025-07-03 19:36:00'),
('salman786@gmail.com', '4369', '2025-07-03 19:38:00'),
('asad.khan@gmail.com', '6216', '2025-07-03 19:40:00'),
('salman786@gmail.com', '6591', '2025-07-03 19:42:00'),
('danish@gmail.com', '8807', '2025-07-03 19:44:00'),
('kamran@gmail.com', '9284', '2025-07-03 19:46:00'),
('soha789@gmail.com', '4635', '2025-07-03 19:48:00'),
('warda123@gmail.com', '1005', '2025-07-03 19:50:00'),
('kamran@gmail.com', '6485', '2025-07-03 19:52:00'),
('rehan007@gmail.com', '4038', '2025-07-03 19:54:00'),
('asad.khan@gmail.com', '8072', '2025-07-03 19:56:00'),
('maria123@gmail.com', '4016', '2025-07-03 19:58:00'),
('usman123@gmail.com', '7839', '2025-07-03 20:00:00'),
('talha987@gmail.com', '4212', '2025-07-03 20:02:00'),
('mehak123@gmail.com', '3124', '2025-07-03 20:04:00'),
('amina456@gmail.com', '8960', '2025-07-03 20:06:00'),
('zara123@gmail.com', '2406', '2025-07-03 20:08:00'),
('warda123@gmail.com', '9001', '2025-07-03 20:10:00'),
('hina777@gmail.com', '1225', '2025-07-03 20:12:00'),
('fatima786@gmail.com', '6987', '2025-07-03 20:14:00'),
('ayman123@gmail.com', '3427', '2025-07-03 20:16:00'),
('hassan23@gmail.com', '5332', '2025-07-03 20:18:00'),
('sajid22@gmail.com', '7865', '2025-07-03 20:20:00'),
('rehan007@gmail.com', '8743', '2025-07-03 20:22:00'),
('inaya123@gmail.com', '5610', '2025-07-03 20:24:00'),
('danish@gmail.com', '3299', '2025-07-03 20:26:00'),
('kamran@gmail.com', '1440', '2025-07-03 20:28:00'),
('zara123@gmail.com', '4081', '2025-07-03 20:30:00'),
('soha789@gmail.com', '7913', '2025-07-03 20:32:00'),
('talha987@gmail.com', '6649', '2025-07-03 20:34:00'),
('fatima786@gmail.com', '1192', '2025-07-03 20:36:00'),
('burhan@gmail.com', '4707', '2025-07-03 20:38:00');

-- --------------------------------------------------------

--
-- Table structure for table `payment_logs`
--

CREATE TABLE `payment_logs` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `log_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_logs`
--

INSERT INTO `payment_logs` (`id`, `booking_id`, `transaction_id`, `error_message`, `log_date`) VALUES
(5, 52, 'pi_auto_1000', 'Card Declined', '2025-07-03 14:00:00'),
(6, 53, 'pi_auto_1001', NULL, '2025-07-03 14:05:00'),
(7, 54, 'pi_auto_1002', NULL, '2025-07-03 14:10:00'),
(8, 55, 'pi_auto_1003', 'Card Declined', '2025-07-03 14:15:00'),
(9, 56, 'pi_auto_1004', NULL, '2025-07-03 14:20:00'),
(10, 57, 'pi_auto_1005', NULL, '2025-07-03 14:25:00'),
(11, 58, 'pi_auto_1006', 'Card Declined', '2025-07-03 14:30:00'),
(12, 59, 'pi_auto_1007', NULL, '2025-07-03 14:35:00'),
(13, 60, 'pi_auto_1008', NULL, '2025-07-03 14:40:00'),
(14, 61, 'pi_auto_1009', 'Card Declined', '2025-07-03 14:45:00'),
(15, 62, 'pi_auto_1010', NULL, '2025-07-03 14:50:00'),
(16, 63, 'pi_auto_1011', NULL, '2025-07-03 14:55:00'),
(17, 64, 'pi_auto_1012', 'Card Declined', '2025-07-03 15:00:00'),
(18, 65, 'pi_auto_1013', NULL, '2025-07-03 15:05:00'),
(19, 66, 'pi_auto_1014', NULL, '2025-07-03 15:10:00'),
(20, 67, 'pi_auto_1015', 'Card Declined', '2025-07-03 15:15:00'),
(21, 68, 'pi_auto_1016', NULL, '2025-07-03 15:20:00'),
(22, 69, 'pi_auto_1017', NULL, '2025-07-03 15:25:00'),
(23, 70, 'pi_auto_1018', 'Card Declined', '2025-07-03 15:30:00'),
(24, 71, 'pi_auto_1019', NULL, '2025-07-03 15:35:00'),
(25, 72, 'pi_auto_1020', NULL, '2025-07-03 15:40:00'),
(26, 73, 'pi_auto_1021', 'Card Declined', '2025-07-03 15:45:00'),
(27, 74, 'pi_auto_1022', NULL, '2025-07-03 15:50:00'),
(28, 75, 'pi_auto_1023', NULL, '2025-07-03 15:55:00'),
(29, 76, 'pi_auto_1024', 'Card Declined', '2025-07-03 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Guest'),
(2, 'Staff'),
(3, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `room_number` varchar(10) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `room_number`, `type`, `price`, `status`) VALUES
(13, '02', 'Double', 6000.00, 'Booked'),
(14, '03', 'Single', 5000.00, 'Booked'),
(15, '04', 'Deluxe', 7000.00, 'Booked'),
(16, '05', 'Single', 2000.00, 'Available'),
(17, '27', 'Executive', 8000.00, 'Available'),
(18, '37', 'Deluxe', 5000.00, 'Booked'),
(19, '41', 'Deluxe', 5000.00, 'Available'),
(20, '33', 'Double', 5000.00, 'Available'),
(21, '21', 'Suite', 5000.00, 'Under Maintenance'),
(22, '31', 'Suite', 5000.00, 'Booked'),
(23, '54', 'Single', 6000.00, 'Under Maintenance'),
(24, '20', 'Suite', 5000.00, 'Available'),
(25, '17', 'Suite', 6000.00, 'Available'),
(26, '16', 'Single', 3000.00, 'Available'),
(27, '101', 'Single', 3000.00, 'Available'),
(28, '102', 'Double', 4000.00, 'Available'),
(29, '103', 'Deluxe', 5000.00, 'Available'),
(30, '104', 'Suite', 6000.00, 'Available'),
(31, '105', 'Executive', 7000.00, 'Booked'),
(32, '106', 'Single', 3000.00, 'Booked'),
(33, '107', 'Double', 4000.00, 'Available'),
(34, '108', 'Deluxe', 5000.00, 'Under Maintenance'),
(35, '109', 'Suite', 6000.00, 'Available'),
(36, '110', 'Executive', 7000.00, 'Available'),
(37, '111', 'Single', 3000.00, 'Available'),
(38, '112', 'Double', 4000.00, 'Booked'),
(39, '113', 'Deluxe', 5000.00, 'Booked'),
(40, '114', 'Suite', 6000.00, 'Available'),
(41, '115', 'Executive', 7000.00, 'Available'),
(42, '116', 'Single', 3000.00, 'Under Maintenance'),
(43, '117', 'Double', 4000.00, 'Available'),
(44, '118', 'Deluxe', 5000.00, 'Booked'),
(45, '119', 'Suite', 6000.00, 'Available'),
(46, '120', 'Executive', 7000.00, 'Available'),
(47, '121', 'Single', 3000.00, 'Booked'),
(48, '122', 'Double', 4000.00, 'Available'),
(49, '123', 'Deluxe', 5000.00, 'Available'),
(50, '124', 'Suite', 6000.00, 'Available'),
(51, '125', 'Executive', 7000.00, 'Booked');

-- --------------------------------------------------------

--
-- Table structure for table `system_users`
--

CREATE TABLE `system_users` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_users`
--

INSERT INTO `system_users` (`id`, `role_id`, `username`, `password`, `email`) VALUES
(1, 3, 'admin', '$2y$10$sTjn8OeSaiiDOqavLzIDLuU4AIakRMfavPysrvwecNIwvnDXOuTHO', 'admin@gmail.com'),
(18, 2, 'guest1', '$2y$10$KRb1n4hfkSqpV6.J.uGxtOV4Doiu0IO2vMyazanjTt8kIvmrtJgF6', 'guest@gmail.com'),
(23, 1, 'hira', '$2y$10$7kvlnQkIT9ICeRCNVGW0S.M.FPk1waLTBVOjKUEERwTKQxKDuShpC', 'hirazaib@gmail.com'),
(24, 1, 'heer', '$2y$10$.MjST7xRtErtftdfDmw1LOD7Nrqx1HcsaS5ywLQBrFSWB9kAB0aqy', 'heer@gmail.com'),
(25, 2, 'staff1', '$2y$10$X.j3FuxovPsC.sKR12Se2e7fg.WmJmORtZOe9gG3hrVIoOeHF0XQa', 'staff1@gmail.com'),
(26, 1, 'ayesha1', '$2y$10$RG66eEaIkrAJsQ7PDpo6DeNKnaHdjtiCrmuj2EAdpsqJcRkyjdByK', 'ayesha1@gmail.com'),
(27, 1, 'ayesha2', '$2y$10$aifX57GjJFb31VYNFROYSepdWTUfElPAuLjP6jdYHQRSmFFSn39/W', 'ayesha2@gmail.com'),
(28, 1, 'areeba', '$2y$10$/x/w9qru4R.6ObepjFQ7veck2ncU.czy2FKQarKSbgTI5xq805kCe', 'areeba@gmail.com'),
(29, 1, 'nabeel', '$2y$10$MXcXSdPM0CbHWr9DZjIFWe/pTqRKingVtx0FdZkrBq87G4SF1dP9a', 'nabeel@gmail.com'),
(30, 1, 'muavia', '$2y$10$G6awEzJEwscs4TzQBSKLJeo44fLA3jL8Og/n6UzuOoqRvWco7nut6', 'muavia@gmail.com'),
(31, 1, 'ammar', '$2y$10$YiwUe4EkNe/yO2kaGdDzoe30Pak/7esA7B6rXxOZRID4TTcii4vHK', 'ammar@gamil.com'),
(33, 1, 'hirazaib', '$2y$10$rsNMKak1ZGtVSlBO5MhdSOiVI9Mr7xZmjzYQ0QTL5TSPw3wp39tJi', 'moaviaa856@gamil.com'),
(34, 1, 'saba', '$2y$10$EDCLOGVXOUryD//jRvrvaeHFMkJemEduLsbDzg5Accfk66u0d358.', 'hirazaib939@gmail.com'),
(35, 1, 'anam', '$2y$10$6jyc6H9cr15zwimv.ymN0uWjw8tBSwMFrXlgWsKDEvVr4ZVmRYgMG', 'moaviaa856@gmail.com'),
(36, 2, 'erum', '$2y$10$i7rLgK5hUUNQCx5DykxMw.NKTpjXo6AfGFf4yUUuv1sTxnmjBxRBK', 'erum@gmail.com'),
(37, 2, 'staff4', '$2y$10$B/RHfyltjhWIiUJzvhfiWORMRoj3knRKqjmQjlE4BZld/WWeYRmKm', 'staff4@gmail.com'),
(38, 2, 'nawab', '$2y$10$sSh9GiMAnhpMFpuePCKxQOkEM/1clemEnJnBgLaYWUc.UszcNk5k2', 'nawab@gmail.com'),
(39, 1, 'david', '$2y$10$V0TlcVn4.ybR/JYuhakICeO9FUJ0g6Hqbh01iTfDHEBgyC1gjfrmW', 'david@gmail.com'),
(40, 1, 'smith', '$2y$10$SXcSh/edSGlShnQFSY2EquV22tq4v.NBT0qqz/.5wm2R0WhjtC8Vu', 'smith@gmail.com'),
(41, 1, 'linda', '$2y$10$gvuCPSEVf.C50BddOgv/T.UOgmgbZKWYYNpXk/fbdsdwRVqkiDlG.', 'linda1234@gmail.com'),
(42, 2, 'staff6', '$2y$10$vWk8c9xZ3tkTGva3Pr1d4.T0KRBdruDWMxyL1OujABNJRupxVTMVy', 'staff@gmail.com'),
(43, 1, 'imamjaffar76', '$2y$10$2WUyztc3xLsw2LjsXFr9POAbAKVh7OlB.EsLDRxCUYS3PLUhqHy5O', 'imamjaffar76@gmail.com'),
(44, 1, 'zara123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'zara123@gmail.com'),
(45, 1, 'danish', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'danish@gmail.com'),
(46, 1, 'maria123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'maria123@gmail.com'),
(47, 1, 'kamran', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'kamran@gmail.com'),
(48, 1, 'amna456', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'amna456@gmail.com'),
(49, 1, 'fahad321', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'fahad321@gmail.com'),
(50, 1, 'soha789', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'soha789@gmail.com'),
(51, 1, 'talha987', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'talha987@gmail.com'),
(52, 1, 'hina777', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'hina777@gmail.com'),
(53, 1, 'usman123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'usman123@gmail.com'),
(54, 1, 'fatima786', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'fatima786@gmail.com'),
(55, 1, 'raheel', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'raheel@gmail.com'),
(56, 1, 'hassan23', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'hassan23@gmail.com'),
(57, 1, 'amna007', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'amna007@gmail.com'),
(58, 1, 'asadkhan', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'asad.khan@gmail.com'),
(59, 1, 'mehak123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'mehak123@gmail.com'),
(60, 1, 'hira999', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'hira999@gmail.com'),
(61, 1, 'salman786', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'salman786@gmail.com'),
(62, 1, 'warda123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'warda123@gmail.com'),
(63, 1, 'ayman123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'ayman123@gmail.com'),
(64, 1, 'sajid22', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'sajid22@gmail.com'),
(65, 1, 'hafsa333', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'hafsa333@gmail.com'),
(66, 1, 'rehan007', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'rehan007@gmail.com'),
(67, 1, 'inaya123', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'inaya123@gmail.com'),
(68, 1, 'burhan', '$2y$10$9fJvJIHn8aE0pYGyV/k1neYMQcS38ZvmjZQ3gOHfT49I2MiT1WYrW', 'burhan@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `fk_system_user` (`system_user_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`),
  ADD KEY `invoices_ibfk_2` (`system_user_id`);

--
-- Indexes for table `payment_logs`
--
ALTER TABLE `payment_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_users`
--
ALTER TABLE `system_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `payment_logs`
--
ALTER TABLE `payment_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `system_users`
--
ALTER TABLE `system_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_system_user` FOREIGN KEY (`system_user_id`) REFERENCES `system_users` (`id`);

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `fk_invoices_system_user` FOREIGN KEY (`system_user_id`) REFERENCES `system_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`system_user_id`) REFERENCES `system_users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_logs`
--
ALTER TABLE `payment_logs`
  ADD CONSTRAINT `payment_logs_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`);

--
-- Constraints for table `system_users`
--
ALTER TABLE `system_users`
  ADD CONSTRAINT `system_users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
