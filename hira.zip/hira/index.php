<?php


session_start(); // Initialize session
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Hotel Management System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <!-- Hero Section -->
<section class="hero">
    <div class="hero-slider">
        <div class="slide"></div>
        <div class="slide"></div>
        <div class="slide"></div>
    </div>
<button class="slider-btn prev">‹</button>
<button class="slider-btn next">›</button>
    <div class="container">
        <h1>Welcome to HA Aura</h1>
        <p>Streamline your hotel operations with our cutting-edge management system. Effortless, intuitive, and powerful.</p>
        <div class="hero-buttons">
            <a href="pages/register.php" class="btn primary">Get Started</a>
            <a href="pages/login.php" class="btn secondary">Log In</a>
        </div>
    </div>
</section>

   <!-- Features Section -->
<section class="features">
    <div class="container">
        <h2>Why Choose HA Aura?</h2>
        <div class="feature-grid">
            <div class="feature-item">
                <div class="feature-image">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h3>Booking Management</h3>
                <p>Simplify reservations with real-time availability and automated confirmations.</p>
            </div>
            <div class="feature-item">
                <div class="feature-image">
                    <i class="fas fa-user-friends"></i>
                </div>
                <h3>Guest Profiles</h3>
                <p>Store guest preferences and history for personalized experiences.</p>
            </div>
            <div class="feature-item">
                <div class="feature-image">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3>Analytics Dashboard</h3>
                <p>Track performance with insightful reports and data visualizations.</p>
            </div>
        </div>
    </div>
</section>

    <!-- About Section -->
 <section class="about">
    <div class="container">
        <h2>About HA Aura</h2>
        <div class="about-content">
            <div class="about-text">
                <p>HA Aura is designed to empower hoteliers with comprehensive tools to manage operations efficiently, enhance guest satisfaction, and boost revenue. Our mission is to make hotel management seamless and luxurious through innovative technology solutions.</p>
                
                <p>With over a decade of experience in the hospitality industry, we understand the unique challenges that hotel owners and managers face daily. From managing reservations and guest preferences to analyzing performance metrics and optimizing revenue streams, HA Aura provides an all-in-one platform that streamlines every aspect of hotel operations.</p>
                
                <p>Our cutting-edge software integrates seamlessly with existing hotel systems, offering real-time insights, automated processes, and personalized guest experiences. Whether you're running a boutique hotel or managing a large chain, HA Aura scales with your business needs, ensuring you stay ahead in the competitive hospitality market.</p>
                
                <p>Join thousands of satisfied hoteliers who have transformed their operations with HA Aura. Experience the difference that smart technology can make in creating memorable guest experiences while maximizing your operational efficiency and profitability.</p>
            </div>
            <div class="about-image">
                <img src="assets/hotel7.jpg" alt="Luxury Hotel Experience">
            </div>
        </div>
    </div>
</section>
    <!-- CTA Section -->
     <section class="faq">
        <div class="container">
            <h2>Frequently Asked Questions</h2>
            <div class="faq-container">
                <div class="faq-item">
                    <div class="faq-question">
                        <span>What is HA Aura and how does it work?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            HA Aura is a comprehensive hotel management system that streamlines operations, manages bookings, tracks guest profiles, and provides detailed analytics. It integrates seamlessly with existing hotel systems to enhance efficiency and guest satisfaction.
                        </div>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <span>How secure is guest data in HA Aura?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            We employ industry-standard encryption and security protocols to protect all guest data. Our system is compliant with data protection regulations and undergoes regular security audits to ensure maximum protection.
                        </div>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <span>Can HA Aura integrate with my existing hotel systems?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Yes! HA Aura is designed to integrate seamlessly with most existing hotel management systems, POS systems, and third-party booking platforms. Our technical team provides full support during the integration process.
                        </div>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <span>What kind of support do you provide?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            We offer 24/7 customer support, comprehensive training programs, regular system updates, and dedicated account managers for enterprise clients. Our support team is always ready to assist with any questions or issues.
                        </div>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <span>Is there a mobile app for HA Aura?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Yes, HA Aura includes mobile applications for both staff and guests. Staff can manage operations on-the-go, while guests can make bookings, check-in/out, and access hotel services through our user-friendly mobile app.
                        </div>
                    </div>
                </div>

                <div class="faq-item">
                    <div class="faq-question">
                        <span>What are the pricing options for HA Aura?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            We offer flexible pricing plans based on hotel size and requirements. From small boutique hotels to large chains, we have packages that scale with your business. Contact our sales team for a customized quote.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews">
        <div class="container">
            <h2>What Our Clients Say</h2>
            <div class="reviews-grid">
                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-avatar">SM</div>
                        <div class="reviewer-info">
                            <h4>Sarah Mitchell</h4>
                            <span class="hotel-name">Grand Plaza Hotel</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="review-text">
                        "HA Aura has revolutionized our hotel operations. The booking management system is intuitive and the analytics dashboard provides invaluable insights. Our guest satisfaction has increased by 40% since implementation.""
                    </p>
                </div>

                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-avatar">RJ</div>
                        <div class="reviewer-info">
                            <h4>Robert Johnson</h4>
                            <span class="hotel-name">Luxury Suites Resort</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="review-text">
                        The guest profile feature is fantastic! We can now provide personalized experiences that our guests love. The system is user-friendly and the support team is exceptional.
                    </p>
                </div>

                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-avatar">MR</div>
                        <div class="reviewer-info">
                            <h4>Maria Rodriguez</h4>
                            <span class="hotel-name">Boutique Inn</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="review-text">
                        As a small hotel owner, I was worried about complex systems. HA Aura is perfect for us - easy to use, affordable, and has helped us compete with larger hotels. Highly recommended!
                    </p>
                </div>

                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-avatar">DL</div>
                        <div class="reviewer-info">
                            <h4>David Lee</h4>
                            <span class="hotel-name">Metropolitan Hotel Chain</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="review-text">
                        Managing multiple properties was challenging until we found HA Aura. The centralized dashboard and real-time reporting have streamlined our operations across all locations.
                    </p>
                </div>

                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-avatar">AL</div>
                        <div class="reviewer-info">
                            <h4>Amanda Thompson</h4>
                            <span class="hotel-name">Seaside Resort</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="review-text">
                        The mobile app is a game-changer! Our guests love the convenience of mobile check-in and our staff can manage everything from their phones. HA Aura has modernized our entire operation.
                    </p>
                </div>

                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-avatar">JW</div>
                        <div class="reviewer-info">
                            <h4>James Wilson</h4>
                            <span class="hotel-name">Business Hotel</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="review-text">
                        The integration process was smooth and the training was comprehensive. Our revenue has increased by 25% thanks to the advanced booking algorithms and pricing optimization features.
                    </p>
                </div>
            </div>
        </div>

        <div class="floating-elements">
            <div class="floating-star">
                <i class="fas fa-star"></i>
            </div>
            <div class="floating-star">
                <i class="fas fa-star"></i>
            </div>
            <div class="floating-star">
                <i class="fas fa-star"></i>
            </div>
            <div class="floating-star">
                <i class="fas fa-star"></i>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
    
</body>
<script src="assets/js/script1.js"></script>
</html>