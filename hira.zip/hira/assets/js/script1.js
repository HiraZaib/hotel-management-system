document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    let currentSlide = 0;

    // ENSURE first slide is visible on load
    slides.forEach((slide, index) => {
        slide.style.opacity = index === 0 ? '1' : '0';
    });

    nextBtn.addEventListener('click', () => {
        slides[currentSlide].style.opacity = 0;
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].style.opacity = 1;
    });

    prevBtn.addEventListener('click', () => {
        slides[currentSlide].style.opacity = 0;
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        slides[currentSlide].style.opacity = 1;
    });

    // Rest of your code...


    nextBtn.addEventListener('click', () => {
        slides[currentSlide].style.opacity = 0;
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].style.opacity = 1;
    });

    prevBtn.addEventListener('click', () => {
        slides[currentSlide].style.opacity = 0;
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        slides[currentSlide].style.opacity = 1;
    });

    let autoSlide = setInterval(() => {
        slides[currentSlide].style.opacity = 0;
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].style.opacity = 1;
    }, 3000);

    document.querySelector('.hero').addEventListener('mouseover', () => clearInterval(autoSlide));
    document.querySelector('.hero').addEventListener('mouseout', () => {
        autoSlide = setInterval(() => {
            slides[currentSlide].style.opacity = 0;
            currentSlide = (currentSlide + 1) % slides.length;
            slides[currentSlide].style.opacity = 1;
        }, 3000);
    });
     const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                const answer = item.querySelector('.faq-answer');
                
                question.addEventListener('click', () => {
                    const isActive = item.classList.contains('active');
                    
                    // Close all other FAQ items
                    faqItems.forEach(otherItem => {
                        otherItem.classList.remove('active');
                        otherItem.querySelector('.faq-answer').classList.remove('active');
                    });
                    
                    // Toggle current item
                    if (!isActive) {
                        item.classList.add('active');
                        answer.classList.add('active');
                    }
                });
            });
        
});
