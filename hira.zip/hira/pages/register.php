<?php
require_once '../includes/config.php';
require_once '../includes/classes/SystemUsers.php';

// No session_start() needed since registration doesn't require an active session

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate input
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    // Validation
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strlen($username) < 3 || strlen($username) > 50) {
        $errors[] = "Username must be between 3 and 50 characters.";
    }

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (!in_array($role, ['Guest', 'Staff', 'Admin'])) {
        $errors[] = "Invalid role selected.";
    }

    // Check for duplicate username and email using SystemUsers class
    if (empty($errors)) {
        try {
            if (SystemUsers::usernameExists($username)) { // Add this static method
                $errors[] = "Username is already taken.";
            }
            if (SystemUsers::emailExists($email)) { // Add this static method
                $errors[] = "Email is already registered.";
            }

            // If no errors, proceed with registration
            if (empty($errors)) {
                $password = password_hash($password, PASSWORD_BCRYPT);
                $user = new SystemUsers(null, null, $username, $password, $email); // Simplified constructor
                $user->setRole($role); // Add setRole method
                $user->save(); // Add save method
                $success = "Registration successful! <a href='login.php'>Login here</a>";
            }
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Register</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
            <h2>Register</h2>
            <?php if (!empty($errors)): ?>
                <div class="error">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success">
                    <p><?php echo $success; ?></p>
                </div>
            <?php endif; ?>
            <form method="POST">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>" required>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="Guest" <?php echo (isset($role) && $role == 'Guest') ? 'selected' : ''; ?>>Guest</option>
                    <option value="Staff" <?php echo (isset($role) && $role == 'Staff') ? 'selected' : ''; ?>>Staff</option>
                </select>
                <button type="submit">Register</button>
            </form>
            <p>Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>