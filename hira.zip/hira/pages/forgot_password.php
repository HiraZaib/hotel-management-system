<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/SystemUsers.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

$errors = [];
$success = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    } else {
        $user = SystemUsers::findByEmail($email); // You need to define this method
        if (!$user) {
            $errors[] = "No account found with that email.";
        } else {
            $code = rand(1000, 9999);
            $_SESSION['reset_code'] = $code;
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_expiry'] = time() + 600;

            // Send email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'hirazaib939@gmail.com';
                $mail->Password = 'rqxrarcmvdevwlmz';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('hirazaib939@gmail.com', 'HA Aura');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Code';
                $mail->Body = "Your password reset code is: <strong>$code</strong>. It expires in 10 minutes.";

                $mail->send();
                $success = "A reset code has been sent to your email.";
                header("Location: verify_code.php");
                exit;
            } catch (Exception $e) {
                $errors[] = "Failed to send reset code. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Forgot Password</h2>
        <?php if ($errors): ?>
            <div class="error"><?php foreach ($errors as $e) echo "<p>$e</p>"; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="success"><p><?php echo $success; ?></p></div>
        <?php endif; ?>
        <form method="POST">
            <label for="email">Email:</label>
            <input type="email" name="email" required value="<?php echo htmlspecialchars($email); ?>">
            <button type="submit">Send Code</button>
        </form>
    </div>
</div>
</body>
</html>
