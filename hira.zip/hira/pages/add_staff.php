<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/SystemUsers.php';

// Restrict access to Admin role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validation
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strlen($username) < 3 || strlen($username) > 50) {
        $errors[] = "Username must be between 3 and 50 characters.";
    }

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (SystemUsers::usernameExists($username)) {
        $errors[] = "Username is already taken.";
    }

    if (SystemUsers::emailExists($email)) {
        $errors[] = "Email is already registered.";
    }

    if (empty($errors)) {
        try {
            $password = password_hash($password, PASSWORD_BCRYPT);
            $user = new SystemUsers(null, 2 , $username, $password, $email); // Name can be empty or set later
            $user->setRole('Staff');

            if ($user->save()) {
                $success = "Staff member added successfully!";
            } else {
                $errors[] = "Failed to add staff member. Please try again.";
            }
        } catch (Exception $e) {
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Add Staff</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
            <h2>Add New Staff</h2>
            <?php if ($success): ?>
                <div class="success">
                    <p><?php echo htmlspecialchars($success); ?></p>
                    <a href="admin_dashboard.php">Back to Dashboard</a>
                </div>
            <?php elseif (!empty($errors)): ?>
                <div class="error">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if (!$success): ?>
                <form method="POST" action="">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="" required>

                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="" required>

                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>

                    <button type="submit">Add Staff</button>
                    <a href="admin_dashboard.php">Cancel</a>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>