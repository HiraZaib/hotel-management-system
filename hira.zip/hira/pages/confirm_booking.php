<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Staff') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $booking = Booking::find($_POST['booking_id']);

    if ($booking && $booking->getStatus() === 'Pending') {
        $booking->setStatus('Confirmed');
        $booking->save();
        header("Location: staff_dashboard.php?success=Booking+Confirmed+Successfully");
    } else {
        header("Location: staff_dashboard.php?error=Invalid+booking+or+status");
    }
}
