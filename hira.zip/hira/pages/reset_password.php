<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/SystemUsers.php';

$errors = [];
$success = '';

if (!isset($_SESSION['reset_verified']) || !$_SESSION['reset_verified'] || !isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($password) || empty($confirm)) {
        $errors[] = "Both fields are required.";
    } elseif ($password !== $confirm) {
        $errors[] = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    } else {
        $user = SystemUsers::findByEmail($_SESSION['reset_email']);
        if ($user) {
            $user->setPassword(password_hash($password, PASSWORD_BCRYPT));
            $user->save();
            $success = "Password reset successfully. You can now <a href='login.php'>login</a>.";
            session_destroy();
        } else {
            $errors[] = "User not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Reset Password</h2>
        <?php if ($errors): ?>
            <div class="error"><?php foreach ($errors as $e) echo "<p>$e</p>"; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="success"><p><?php echo $success; ?></p></div>
        <?php else: ?>
            <form method="POST">
                <label for="password">New Password:</label>
                <input type="password" name="password" required>
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" name="confirm_password" required>
                <button type="submit">Reset Password</button>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
