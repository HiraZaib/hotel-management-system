<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Room.php';

// Restrict access to Staff role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Staff') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $room_id = $_POST['room_id'] ?? null;
    $status = $_POST['status'] ?? null;

    if ($room_id && in_array($status, ['Available', 'Booked', 'Under Maintenance'])) {
        try {
            $room = Room::find($room_id); // Use existing find method
            if ($room) {
                $room->setStatus($status); // Use existing setStatus method
                $room->save(); // Use existing save method
                header("Location: staff_dashboard.php?success=" . urlencode("Room status updated successfully"));
                exit();
            } else {
                header("Location: staff_dashboard.php?error=" . urlencode("Room not found"));
                exit();
            }
        } catch (Exception $e) {
            header("Location: staff_dashboard.php?error=" . urlencode("Error updating room status: " . $e->getMessage()));
            exit();
        }
    } else {
        header("Location: staff_dashboard.php?error=" . urlencode("Invalid room ID or status"));
        exit();
    }
} else {
    header("Location: staff_dashboard.php?error=" . urlencode("Invalid request method"));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Update Room Status</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
            <h2>Update Room Status</h2>
            <p>This page processes room status updates automatically. You will be redirected shortly.</p>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>