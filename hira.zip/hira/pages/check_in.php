<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';
require_once '../includes/classes/Room.php';
require_once '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Restrict access to Staff role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Staff') {
    header("Location: login.php");
    exit();
}

$booking_id = $_GET['booking_id'] ?? null;
$success = '';
$error = '';
$booking = null;

if ($booking_id) {
    try {
        $booking = Booking::find($booking_id);
        
        if ($booking) {
            if ($booking->getStatus() == 'Confirmed') {
                $booking->setStatus('Checked-In');
                $booking_saved = $booking->save();

                $room = Room::find($booking->getRoomId());
                if ($room) {
                    $room->setStatus('Booked');
                    $room_saved = $room->save();

                    if ($booking_saved && $room_saved) {
                        // Send welcome email to system user
                        $mail = new PHPMailer(true);
                        try {
                            $mail->isSMTP();
                            $mail->Host = 'smtp.gmail.com';
                            $mail->SMTPAuth = true;
                            $mail->Username = 'hirazaib939@gmail.com';
                            $mail->Password = 'rqxrarcmvdevwlmz';
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                            $mail->Port = 587;

                            $mail->setFrom('hirazaib939@gmail.com', 'HA Aura');
                            $mail->addAddress($booking->getEmail(), $booking->getUsername());

                            $mail->isHTML(true);
                            $mail->Subject = 'Welcome to HA Aura - Check-In Confirmation';
                            $mail->Body = "Dear {$booking->getUsername()},<br><br>
                                           Welcome to HA Aura! You have successfully checked in.<br><br>
                                           <strong>Booking Details:</strong><br>
                                           Booking ID: {$booking->getId()}<br>
                                           Room Number: {$booking->getRoomNumber()}<br>
                                           Check-In Date: " . date('Y-m-d') . "<br>
                                           Check-Out Date: {$booking->getCheckOut()}<br>
                                           Total Amount: PKR {$booking->getTotalPrice()}<br><br>
                                           We hope you enjoy your stay with us!<br><br>
                                           For any assistance, please contact our front desk.<br><br>
                                           Best regards,<br>HA Aura Team";

                            $mail->AltBody = "Dear {$booking->getUsername()},\n\n
                                              Welcome to HA Aura! You have successfully checked in.\n\n
                                              Booking Details:\n
                                              Booking ID: {$booking->getId()}\n
                                              Room Number: {$booking->getRoomNumber()}\n
                                              Check-In Date: " . date('Y-m-d') . "\n
                                              Check-Out Date: {$booking->getCheckOut()}\n
                                              Total Amount: PKR {$booking->getTotalPrice()}\n\n
                                              We hope you enjoy your stay with us!\n\n
                                              For any assistance, please contact our front desk.\n\n
                                              Best regards,\nHA Aura Team";

                            $mail->send();
                            $success = "Guest successfully checked in! Welcome email sent to {$booking->getUsername()}.";

                        } catch (Exception $e) {
                            $success = "Guest successfully checked in! (Email notification failed: {$mail->ErrorInfo})";
                        }

                    } else {
                        $error = "Failed to update booking or room status in database.";
                    }
                } else {
                    $error = "Room not found for this booking.";
                }

            } elseif ($booking->getStatus() == 'Checked-In') {
                $error = "Guest is already checked in.";
            } elseif ($booking->getStatus() == 'Checked-Out') {
                $error = "This booking has already been completed (checked out).";
            } else {
                $error = "Booking is not confirmed yet. Current status: " . $booking->getStatus();
            }

        } else {
            $error = "Booking not found.";
        }

    } catch (Exception $e) {
        $error = "Error processing check-in: " . $e->getMessage();
    }

} else {
    $error = "No booking ID provided.";
}

// Auto-redirect after successful check-in
if ($success) {
    header("refresh:10;url=staff_dashboard.php?success=" . urlencode($success));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Check-In Guest</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
            <h2>Check-In Guest</h2>
            
            <?php if ($booking && !$success && !$error): ?>
                <div class="booking-details">
                    <h3>Booking Details</h3>
                    <p><strong>Booking ID:</strong> <?php echo htmlspecialchars($booking->getId()); ?></p>
                    <p><strong>Username:</strong> <?php echo htmlspecialchars($booking->getUsername()); ?></p>
                    <p><strong>Room Number:</strong> <?php echo htmlspecialchars($booking->getRoomNumber()); ?></p>
                    <p><strong>Check-In Date:</strong> <?php echo htmlspecialchars($booking->getCheckIn()); ?></p>
                    <p><strong>Check-Out Date:</strong> <?php echo htmlspecialchars($booking->getCheckOut()); ?></p>
                    <p><strong>Total Amount:</strong> PKR <?php echo htmlspecialchars($booking->getTotalPrice()); ?></p>
                    <p><strong>Current Status:</strong> <?php echo htmlspecialchars($booking->getStatus()); ?></p>
                </div>
            <?php endif; ?>
            

            <?php if ($success): ?>
                <div class="success">
                    <p><?php echo htmlspecialchars($success); ?></p>
                    <p><em>Redirecting to dashboard in 10 seconds...</em></p>
                    <a href="staff_dashboard.php">Return to Dashboard Now</a>
                </div>
            <?php elseif ($error): ?>
                <div class="error">
                    <p><?php echo htmlspecialchars($error); ?></p>
                    <a href="staff_dashboard.php">Return to Dashboard</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>
