<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Guest') {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

$booking_id = $_GET['id'] ?? null;
$success = '';
$error = '';

if ($booking_id) {
    $booking = Booking::findByIdAndUserId($booking_id, $_SESSION['user_id']);

    if (!$booking) {
        $error = "Booking not found or unauthorized access.";
    } elseif ($booking->getStatus() !== 'Confirmed') {
        $error = "Only confirmed bookings can be canceled.";
    } else {
        $booking->setStatus('Canceled');

        if ($booking->save()) {
            $success = "Booking (ID: {$booking->getId()}) has been canceled successfully.";
        } else {
            $error = "Failed to cancel booking. Please try again.";
        }
    }
} else {
    $error = "Invalid booking ID.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HA Aura - Cancel Booking</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<div class="container">
    <div class="card">
        <h2>Cancel Booking</h2>
        <?php if ($success): ?>
            <div class="success">
                <p><?php echo htmlspecialchars($success); ?></p>
                <a href="<?php echo BASE_URL; ?>pages/guest_dashboard.php">Return to Dashboard</a>
            </div>
        <?php else: ?>
            <div class="error">
                <p><?php echo htmlspecialchars($error); ?></p>
                <a href="<?php echo BASE_URL; ?>pages/guest_dashboard.php">Return to Dashboard</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
</body>
</html>
