<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Room.php';
require_once '../includes/classes/SystemUsers.php';
require_once '../includes/classes/Booking.php';

// Restrict access to Admin role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Fetch statistics
$total_rooms = Room::getTotalRooms();
$booked_rooms = Room::getBookedRooms();
$total_staff = SystemUsers::getTotalStaff();

// Fetch data
$rooms = Room::getAll();
$staff = SystemUsers::getAllStaff();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script>
function generateReport(mode) {
    // Set the mode
    document.getElementById('report_mode').value = mode;
    
    // Debug: Check if mode is set correctly
    console.log('Mode set to:', mode);
    
    // If download mode, remove target="_blank" to allow download
    const form = document.getElementById('reportForm');
    if (mode === 'download') {
        form.removeAttribute('target');
    } else {
        form.setAttribute('target', '_blank');
    }
    console.log("Generating report with mode:", mode);

    // Submit the form
    form.submit();
    console.log("Generating report with mode huh:", mode);

}
    </script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
    <h2>Generate Reports</h2>
    <form id="reportForm" action="generate_report.php" method="GET" target="_blank">
        <label for="report_range">Select Report Range:</label>
        <select name="range" id="report_range" required>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly</option>
        </select>

        <input type="hidden" name="mode" id="report_mode" value="preview">

        <button type="button" onclick="generateReport('preview')">Preview PDF</button>
        <button type="button" onclick="generateReport('download')">Download PDF</button>
    </form>
</div>

        

            


        <div class="card">
            <h2>Hotel Statistics</h2>
            <p><strong>Total Rooms:</strong> <?php echo htmlspecialchars($total_rooms); ?></p>
            <p><strong>Booked Rooms:</strong> <?php echo htmlspecialchars($booked_rooms); ?></p>
            <p><strong>Available Rooms:</strong> <?php echo htmlspecialchars($total_rooms - $booked_rooms); ?></p>
            <p><strong>Total Staff:</strong> <?php echo htmlspecialchars($total_staff); ?></p>
        </div>

        <div class="card">
            <h2>Room Management</h2>
            <table>
                <thead>
                    <tr>
                        <th>Room Number</th>
                        <th>Type</th>
                        <th>Price (PKR)</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rooms as $room): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($room->getRoomNumber()); ?></td>
                            <td><?php echo htmlspecialchars($room->getType()); ?></td>
                            <td><?php echo htmlspecialchars($room->getPrice()); ?></td>
                            <td><?php echo htmlspecialchars($room->getStatus()); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h2>Staff List</h2>
            <a href="add_staff.php" class="btn-small btn-modify">Add Staff</a>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($staff as $member): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($member->getUsername()); ?></td>
                            <td><?php echo htmlspecialchars($member->getEmail()); ?></td>
                            <td><?php echo htmlspecialchars($member->getRole()); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </div>
    <?php include '../includes/footer.php'; ?>



</body>
</html>
