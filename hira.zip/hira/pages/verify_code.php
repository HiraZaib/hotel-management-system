<?php
session_start();

$errors = [];
$code_input = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code_input = trim($_POST['code'] ?? '');

    if (empty($code_input)) {
        $errors[] = "Please enter the code.";
    } elseif (!isset($_SESSION['reset_code']) || !isset($_SESSION['reset_expiry']) || time() > $_SESSION['reset_expiry']) {
        $errors[] = "Code has expired or is invalid.";
    } elseif ($code_input != $_SESSION['reset_code']) {
        $errors[] = "Incorrect code.";
    } else {
        $_SESSION['reset_verified'] = true;
        header("Location: reset_password.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verify Code</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container">
    <div class="card">
        <h2>Verify Code</h2>
        <?php if ($errors): ?>
            <div class="error"><?php foreach ($errors as $e) echo "<p>$e</p>"; ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="code">Enter 4-digit Code:</label>
            <input type="text" name="code" maxlength="4" required>
            <button type="submit">Verify</button>
        </form>
    </div>
</div>
</body>
</html>
