<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';
require_once '../includes/classes/Room.php';
require_once '../includes/classes/Invoice.php';
require_once '../includes/classes/PaymentLog.php';
require_once '../vendor/autoload.php';

use Stripe\Stripe;
use Stripe\PaymentIntent;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize database connection
global $pdo;
if (!isset($pdo) || !$pdo) {
    // Try different ways to get database connection based on your setup
    if (class_exists('Database')) {
        $pdo = Database::getConnection();
    } elseif (function_exists('getDBConnection')) {
        $pdo = getDBConnection();
    } elseif (defined('DB_HOST') && defined('DB_NAME') && defined('DB_USER') && defined('DB_PASS')) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
        }
    }
}

Stripe::setApiKey('sk_test_51RVE9rITbMHz7SKKID7gGqtxDsOb05o3wJVLfwWljFqlvHTffXPMwe9NNHhe8Aym4jENtbiyyFQ4JAhfIMfShrT400BaMltrdX');

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Staff') {
    header("Location: login.php");
    exit();
}

$booking_id = $_GET['booking_id'] ?? null;
$success = '';
$error = '';
$client_secret = '';
$booking = null;

// Add debugging function
function debugLog($message) {
    $timestamp = date('Y-m-d H:i:s');
    error_log("[$timestamp] CHECKOUT DEBUG: $message");
}

if ($booking_id) {
    try {
        $booking = Booking::find($booking_id);
        debugLog("Processing booking ID: $booking_id");
        debugLog("Booking found: " . ($booking ? 'Yes' : 'No'));
        
        if ($booking) {
            debugLog("Current booking status: " . $booking->getStatus());
            debugLog("Transaction ID: " . ($booking->getTransactionId() ?? 'None'));
            debugLog("Request method: " . $_SERVER['REQUEST_METHOD']);
            debugLog("POST data: " . print_r($_POST, true));
            
            // Check if booking is already processed
            if ($booking->getStatus() == 'Checked-Out') {
                $error = "This booking has already been checked out.";
                $error .= "<br><strong>Transaction ID:</strong> " . ($booking->getTransactionId() ?? 'N/A');
                $error .= "<br><strong>Status:</strong> " . $booking->getStatus();
                
                // Get invoice details if available
                try {
                    // Get database connection from config
                    global $pdo;
                    if (!$pdo && class_exists('Database')) {
                        $pdo = Database::getConnection();
                    }
                    
                    if ($pdo) {
                        $stmt = $pdo->prepare("SELECT * FROM invoices WHERE booking_id = ? ORDER BY created_at DESC LIMIT 1");
                        $stmt->execute([$booking_id]);
                        $invoice = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($invoice) {
                            $error .= "<br><strong>Invoice ID:</strong> " . $invoice['id'];
                            $error .= "<br><strong>Amount:</strong> PKR " . $invoice['amount'];
                            $error .= "<br><strong>Invoice Status:</strong> " . $invoice['status'];
                            $error .= "<br><strong>Processed:</strong> " . $invoice['created_at'];
                        }
                    }
                } catch (Exception $e) {
                    debugLog("Error fetching invoice details: " . $e->getMessage());
                }
                
                debugLog("Booking already checked out - showing details");
            }
            // Handle payment confirmation (POST request)
            elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_intent_id'])) {
                debugLog("Processing payment confirmation for PI: " . $_POST['payment_intent_id']);
                
                // Double-check booking status before processing
                $booking = Booking::find($booking_id); // Refresh booking data
                if ($booking->getStatus() !== 'Checked-In') {
                    $error = "Booking status changed during processing. Current status: " . $booking->getStatus();
                    debugLog("Booking status changed during processing: " . $booking->getStatus());
                } else {
                    try {
                        $pi = PaymentIntent::retrieve($_POST['payment_intent_id']);
                        debugLog("Payment Intent retrieved - Status: " . $pi->status);
                        
                        if ($pi->status === 'succeeded') {
                            // Get database connection
                            global $pdo;
                            if (!$pdo && class_exists('Database')) {
                                $pdo = Database::getConnection();
                            }
                            
                            // Start transaction to prevent race conditions (if PDO available)
                            if ($pdo) {
                                $pdo->beginTransaction();
                            }
                            
                            try {
                                // Double-check booking hasn't been processed by another request
                                if ($pdo) {
                                    $stmt = $pdo->prepare("SELECT status, transaction_id FROM bookings WHERE id = ? FOR UPDATE");
                                    $stmt->execute([$booking_id]);
                                    $current_booking = $stmt->fetch(PDO::FETCH_ASSOC);
                                    
                                    if ($current_booking['status'] !== 'Checked-In') {
                                        $pdo->rollBack();
                                        $error = "Booking was already processed by another request. Status: " . $current_booking['status'];
                                        debugLog("Race condition detected - booking already processed");
                                        return;
                                    }
                                }
                                
                                // Process the checkout
                                $booking->setTransactionId($pi->id);
                                
                                // Get invoice ID from payment intent metadata
                                $invoice_id = $pi->metadata['invoice_id'] ?? null;
                                debugLog("Invoice ID from metadata: " . ($invoice_id ?? 'None'));
                                
                                if ($invoice_id) {
                                    Invoice::updateStatus($invoice_id, 'Paid');
                                    debugLog("Invoice $invoice_id marked as paid");
                                }
                                
                                // Update booking status
                                $booking->setStatus('Checked-Out');
                                $booking->save();
                                debugLog("Booking status updated to Checked-Out");

                                // Update room status
                                $room = Room::find($booking->getRoomId());
                                if ($room) {
                                    $room->setStatus('Available');
                                    $room->save();
                                    debugLog("Room " . $room->getName() . " marked as Available");
                                }

                                if ($pdo) {
                                    $pdo->commit();
                                    debugLog("Transaction committed successfully");
                                }

                                // Send email (outside transaction to avoid delays)
                                try {
                                    $mail = new PHPMailer(true);
                                    $mail->isSMTP();
                                    $mail->Host = 'smtp.gmail.com';
                                    $mail->SMTPAuth = true;
                                    $mail->Username = 'hirazaib939@gmail.com';
                                    $mail->Password = 'rqxrarcmvdevwlmz';
                                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                                    $mail->Port = 587;

                                    $mail->setFrom('hirazaib939@gmail.com', 'HA Aura');
                                    $mail->addAddress($booking->getEmail(), $booking->getUsername());
                                    $mail->isHTML(true);
                                    $mail->Subject = 'Check-Out Confirmation - HA Aura';
                                    $mail->Body = "Dear {$booking->getUsername()},<br><br>
                                                   You have successfully checked out from Room {$room->getName()} on " . date('Y-m-d') . ".<br>
                                                   <strong>Invoice Details:</strong><br>
                                                   Invoice ID: $invoice_id<br>
                                                   Transaction ID: {$pi->id}<br>
                                                   Amount: PKR {$booking->getTotalPrice()}<br>
                                                   Status: Paid<br><br>
                                                   Thank you for staying with us!<br><br>
                                                   Best regards,<br>HA Aura";
                                    $mail->send();
                                    debugLog("Confirmation email sent successfully");
                                } catch (Exception $mail_error) {
                                    debugLog("Email sending failed: " . $mail_error->getMessage());
                                }

                                $success = "Guest checked out successfully. Payment processed and invoice generated (Invoice ID: $invoice_id).";
                                debugLog("Checkout completed successfully");
                                
                            } catch (Exception $transaction_error) {
                                if ($pdo) {
                                    $pdo->rollBack();
                                }
                                debugLog("Transaction failed: " . $transaction_error->getMessage());
                                throw $transaction_error;
                            }
                        } else {
                            $error_message = $pi->last_payment_error?->message ?? 'Payment not completed';
                            $error = "Payment failed: " . $error_message;
                            debugLog("Payment failed: " . $error_message);
                            
                            // Log failed payment
                            $invoice_id = $pi->metadata['invoice_id'] ?? null;
                            if ($invoice_id) {
                                Invoice::updateStatus($invoice_id, 'Failed');
                            }
                            PaymentLog::logFailedPayment($booking_id, $pi->id, $error);
                        }
                    } catch (Exception $stripe_error) {
                        $error = "Payment processing error: " . $stripe_error->getMessage();
                        debugLog("Stripe error: " . $stripe_error->getMessage());
                    }
                }
            }
            // Create payment intent for checked-in bookings
            elseif ($booking->getStatus() == 'Checked-In') {
                debugLog("Creating payment intent for checked-in booking");
                
                try {
                    // Check if there's already a pending payment intent for this booking
                    global $pdo;
                    if (!$pdo && class_exists('Database')) {
                        $pdo = Database::getConnection();
                    }
                    
                    $existing_invoice = null;
                    if ($pdo) {
                        $stmt = $pdo->prepare("SELECT * FROM invoices WHERE booking_id = ? AND status IN ('Pending', 'Processing') ORDER BY created_at DESC LIMIT 1");
                        $stmt->execute([$booking_id]);
                        $existing_invoice = $stmt->fetch(PDO::FETCH_ASSOC);
                    }
                    
                    if ($existing_invoice) {
                        debugLog("Found existing invoice: " . $existing_invoice['id']);
                        $invoice_id = $existing_invoice['id'];
                    } else {
                        // Create new invoice
                        $invoice_id = Invoice::create($booking->getId(), $booking->getSystemUserId(), $booking->getTotalPrice());
                        debugLog("Created new invoice: $invoice_id");
                    }

                    // Create payment intent
                    if ($booking->getTotalPrice() < 200) {
    $error = "⚠️ Minimum payment amount is PKR 200 due to Stripe restrictions.";
    debugLog($error);
} else {
    // Create payment intent
    $payment_intent = PaymentIntent::create([
        'amount' => intval($booking->getTotalPrice() * 100),
        'currency' => 'pkr',
        'description' => "Payment for Booking ID: {$booking->getId()}",
        'metadata' => [
            'invoice_id' => $invoice_id, 
            'booking_id' => $booking->getId(),
            'created_by' => 'checkout_system'
        ],
        'automatic_payment_methods' => ['enabled' => true],
    ]);

    $client_secret = $payment_intent->client_secret;
    debugLog("Payment Intent created - ID: " . $payment_intent->id . ", Amount: " . $payment_intent->amount);
}

                } catch (Exception $stripe_error) {
                    $error = "Failed to create payment intent: " . $stripe_error->getMessage();
                    debugLog("Stripe PaymentIntent creation error: " . $stripe_error->getMessage());
                }
            } else {
                $error = "Booking is not in a 'Checked-In' state. Current status: " . $booking->getStatus();
                debugLog("Invalid booking status for checkout: " . $booking->getStatus());
            }
        } else {
            $error = "Booking not found.";
            debugLog("Booking not found for ID: $booking_id");
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
        debugLog("General error: " . $e->getMessage());
    }
} else {
    $error = "No booking ID provided.";
    debugLog("No booking ID provided in request");
}

// Redirect on success with delay
if ($success) {
    debugLog("Success - redirecting to dashboard");
    header("refresh:5;url=staff_dashboard.php?success=" . urlencode($success));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Check-Out Guest</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://js.stripe.com/v3/"></script>
    <style>
        .debug-info {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 15px;
            margin: 20px 0;
            font-family: monospace;
            font-size: 12px;
        }
        .booking-details {
            background: #e7f3ff;
            border: 1px solid #bee5eb;
            border-radius: 4px;
            padding: 15px;
            margin: 20px 0;
        }
        .already-processed {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 4px;
            padding: 20px;
            margin: 20px 0;
        }
        .payment-section {
            background: #f8f9fa;
            border-radius: 4px;
            padding: 20px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
            <h2>Check-Out Guest</h2>
            
            <?php if ($success): ?>
                <div class="success">
                    <p><?php echo htmlspecialchars($success); ?></p>
                    <p><em>Redirecting to dashboard in 5 seconds...</em></p>
                    <a href="staff_dashboard.php">Return to Dashboard</a>
                </div>
            <?php elseif ($booking && $booking->getStatus() == 'Checked-Out'): ?>
                <div class="already-processed">
                    <h3>⚠️ Booking Already Processed</h3>
                    <p><?php echo $error; ?></p>
                    <p><strong>This checkout has been completed.</strong> If this was unexpected, please check:</p>
                    <ul>
                        <li>Whether another staff member processed this booking</li>
                        <li>If there are any webhook configurations that auto-process payments</li>
                        <li>Browser history - avoid refreshing payment pages</li>
                    </ul>
                    <a href="staff_dashboard.php" class="btn">Return to Dashboard</a>
                </div>
            <?php elseif ($error && !$client_secret): ?>
                <div class="error">
                    <p><?php echo $error; ?></p>
                    <a href="staff_dashboard.php">Return to Dashboard</a>
                </div>
            <?php elseif ($client_secret && $booking): ?>
                <div class="booking-details">
                    <h3>Booking Details</h3>
                    <p><strong>Guest:</strong> <?php echo htmlspecialchars($booking->getUsername()); ?></p>
                    <p><strong>Room:</strong> <?php 
                        $room = Room::find($booking->getRoomId());
                        echo $room ? htmlspecialchars($room->getRoomNumber()) : 'N/A';
                    ?></p>
                    <p><strong>Amount:</strong> PKR <?php echo htmlspecialchars($booking->getTotalPrice()); ?></p>
                    <p><strong>Current Status:</strong> <?php echo htmlspecialchars($booking->getStatus()); ?></p>
                </div>
                
                <div class="payment-section">
                    <form id="payment-form">
                        <h3>💳 Payment Information</h3>
                        <p><em>Process payment to complete checkout</em></p>
                        
                        <div id="card-element" style="margin: 20px 0; padding: 15px; border: 1px solid #ccc; border-radius: 4px; background: white;">
                            <!-- Stripe Elements will replace this with a card input -->
                        </div>
                        <div id="card-errors" role="alert" style="color: red; margin-top: 10px;"></div>
                        
                        <button type="button" id="submit-payment" style="margin-top: 20px; padding: 12px 24px; background: #007cba; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px;">
                            💸 Process Payment & Check Out
                        </button>
                        
                        <div id="payment-status" style="margin-top: 10px; display: none;">
                            <p><em>🔄 Processing payment... Please wait.</em></p>
                        </div>
                    </form>
                </div>
                
                <?php if ($error): ?>
                    <div class="error" style="margin-top: 20px;">
                        <p><?php echo htmlspecialchars($error); ?></p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($client_secret && $booking): ?>
    <script>
        console.log('Initializing Stripe checkout for booking:', <?php echo json_encode($booking_id); ?>);
        
        const stripe = Stripe('pk_test_51RVE9rITbMHz7SKKFGjEYAKNW54fORMF1dmEhfXN4EosTMCwtC9LUAYwQnWxVSagCQsjjUjvLgNcLOzRzNevbnxH006uEJDTG8');
        
        document.addEventListener('DOMContentLoaded', () => {
            const elements = stripe.elements();
            const cardElement = elements.create('card', {
                style: {
                    base: {
                        fontSize: '16px',
                        color: '#424770',
                        '::placeholder': {
                            color: '#aab7c4',
                        },
                    },
                },
            });
            
            cardElement.mount('#card-element');

            const cardErrors = document.getElementById('card-errors');
            cardElement.on('change', (event) => {
                if (event.error) {
                    cardErrors.textContent = event.error.message;
                } else {
                    cardErrors.textContent = '';
                }
            });

            const submitButton = document.getElementById('submit-payment');
            const paymentStatus = document.getElementById('payment-status');
            let paymentInProgress = false;
            
            submitButton.addEventListener('click', async () => {
                if (paymentInProgress) {
                    console.log('Payment already in progress, ignoring click');
                    return;
                }
                
                paymentInProgress = true;
                submitButton.disabled = true;
                submitButton.textContent = '🔄 Processing...';
                paymentStatus.style.display = 'block';
                cardErrors.textContent = '';

                console.log('Starting payment confirmation...');

                try {
                    const { paymentIntent, error } = await stripe.confirmCardPayment('<?php echo htmlspecialchars($client_secret, ENT_QUOTES); ?>', {
                        payment_method: {
                            card: cardElement,
                            billing_details: {
                                name: '<?php echo htmlspecialchars($booking->getUsername(), ENT_QUOTES); ?>',
                                email: '<?php echo htmlspecialchars($booking->getEmail(), ENT_QUOTES); ?>',
                            },
                        },
                    });

                    if (error) {
                        console.error('Payment failed:', error);
                        cardErrors.textContent = 'Payment failed: ' + error.message;
                        resetPaymentButton();
                    } else {
                        console.log('Payment succeeded:', paymentIntent.id);
                        
                        // Submit to server for processing
                        const formData = new FormData();
                        formData.append('payment_intent_id', paymentIntent.id);
                        
                        const response = await fetch(window.location.href, {
                            method: 'POST',
                            body: formData,
                        });
                        
                        if (response.ok) {
                            console.log('Server processing successful, reloading page');
window.location.href = "staff_dashboard.php?success=" + encodeURIComponent("Checkout successful");
                        } else {
                            throw new Error('Server error processing payment confirmation');
                        }
                    }
                } catch (err) {
                    console.error('Payment error:', err);
                    cardErrors.textContent = 'An error occurred: ' + err.message;
                    resetPaymentButton();
                }
            });
            
            function resetPaymentButton() {
                paymentInProgress = false;
                submitButton.disabled = false;
                submitButton.textContent = '💸 Process Payment & Check Out';
                paymentStatus.style.display = 'none';
            }
        });
    </script>
    <?php endif; ?>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>