<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';
require_once '../includes/classes/Room.php';

// Restrict access to Staff role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Staff') {
    header("Location: login.php");
    exit();
}

// Fetch recent bookings
$bookings = Booking::getRecent(10);

// Fetch rooms
$rooms = Room::getAll();

// Handle username or booking ID search
$search_results = [];
if (isset($_POST['search_guest'])) {
    $search_term = trim($_POST['search_term']);
    $search_results = Booking::searchByUsernameOrId($search_term);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Staff Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script>
        function confirmCheckout(bookingId) {
            if (confirm('Are you sure you want to check out this guest?')) {
                window.location.href = 'check_out.php?booking_id=' + bookingId;
            }
        }
    </script>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <?php if (isset($_GET['success'])): ?>
            <div class="success">
                <p><?php echo htmlspecialchars($_GET['success']); ?></p>
            </div>
        <?php elseif (isset($_GET['error'])): ?>
            <div class="error">
                <p><?php echo htmlspecialchars($_GET['error']); ?></p>
            </div>
        <?php endif; ?>

        <!-- Search Section -->
        <div class="card">
            <h2>Search Booking</h2>
            <form method="POST">
                <label for="search_term">Search by Username or Booking ID</label>
                <input type="text" id="search_term" name="search_term" required>
                <button type="submit" name="search_guest">Search</button>
            </form>

            <?php if (!empty($search_results)): ?>
                <h3>Search Results</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Username</th>
                            <th>Room Number</th>
                            <th>Check-In</th>
                            <th>Check-Out</th>
                            <th>Status</th>
                            <th>Transaction ID</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($search_results as $result): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($result->getId()); ?></td>
                                <td><?php echo htmlspecialchars($result->getUsername()); ?></td>
                                <td><?php echo htmlspecialchars($result->getRoomNumber()); ?></td>
                                <td><?php echo htmlspecialchars($result->getCheckIn()); ?></td>
                                <td><?php echo htmlspecialchars($result->getCheckOut()); ?></td>
                                <td><?php echo htmlspecialchars($result->getStatus()); ?></td>
                                <td><?php echo htmlspecialchars($result->getTransactionId() ?? 'N/A'); ?></td>
                                <td>
                                    <?php if ($result->getStatus() == 'Confirmed'): ?>
                                        <a href="check_in.php?booking_id=<?php echo $result->getId(); ?>">Check-In</a>
                                    <?php elseif ($result->getStatus() == 'Checked-In'): ?>
                                        <a href="javascript:void(0)" onclick="confirmCheckout(<?php echo $result->getId(); ?>)">Check-Out</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php elseif (isset($_POST['search_guest'])): ?>
                <p>No results found.</p>
            <?php endif; ?>
        </div>

        <!-- Recent Bookings -->
        <div class="card">
            <h2>Recent Bookings</h2>
            <?php if (empty($bookings)): ?>
                <p>No recent bookings found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Username</th>
                            <th>Room Number</th>
                            <th>Check-In</th>
                            <th>Check-Out</th>
                            <th>Total Price (PKR)</th>
                            <th>Status</th>
                            <th>Transaction ID</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($booking->getId()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getUsername()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getRoomNumber()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getCheckIn()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getCheckOut()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getTotalPrice()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getStatus()); ?></td>
                                <td><?php echo htmlspecialchars($booking->getTransactionId() ?? 'N/A'); ?></td>
                                <td>
                                <?php if ($booking->getStatus() == 'Pending'): ?>
                                <form method="POST" action="confirm_booking.php" style="display:inline;">
                                <input type="hidden" name="booking_id" value="<?php echo $booking->getId(); ?>">
                                <button type="submit">Confirm</button>
                                </form>
                                <?php elseif ($booking->getStatus() == 'Confirmed'): ?>
                                        <a href="check_in.php?booking_id=<?php echo $booking->getId(); ?>">Check-In</a>
                                    <?php elseif ($booking->getStatus() == 'Checked-In'): ?>
                                        <a href="javascript:void(0)" onclick="confirmCheckout(<?php echo $booking->getId(); ?>)">Check-Out</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- Room Status -->
        <div class="card">
            <h2>Room Status</h2>
            <table>
                <thead>
                    <tr>
                        <th>Room Number</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rooms as $room): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($room->getRoomNumber()); ?></td>
                            <td><?php echo htmlspecialchars($room->getType()); ?></td>
                            <td><?php echo htmlspecialchars($room->getStatus()); ?></td>
                            <td>
                                <form method="POST" action="update_room_status.php">
                                    <input type="hidden" name="room_id" value="<?php echo $room->getId(); ?>">
                                    <select name="status" required>
                                        <option value="Available" <?php echo $room->getStatus() == 'Available' ? 'selected' : ''; ?>>Available</option>
                                        <option value="Booked" <?php echo $room->getStatus() == 'Booked' ? 'selected' : ''; ?>>Booked</option>
                                        <option value="Under Maintenance" <?php echo $room->getStatus() == 'Under Maintenance' ? 'selected' : ''; ?>>Under Maintenance</option>
                                    </select>
                                    <button type="submit">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>