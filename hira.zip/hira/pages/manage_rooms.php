<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Room.php';

// Restrict access to Admin role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

$success = '';
$error = '';
$rooms = [];

// Fetch all rooms using Room class
try {
    $rooms = Room::getAll(); // Add this static method to Room class
} catch (Exception $e) {
    $error = "Error fetching rooms: " . $e->getMessage();
}

// Handle Add/Edit Room
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $room_number = trim($_POST['room_number'] ?? '');
    $type = trim($_POST['type'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $status = $_POST['status'] ?? 'Available';

    // Validate inputs
    if (empty($room_number) || empty($type) || $price <= 0) {
        $error = "All fields are required, and price must be greater than 0.";
    } elseif (!in_array($status, ['Available', 'Booked', 'Under Maintenance'])) {
        $error = "Invalid status selected.";
    } else {
        try {
            if ($action == 'add') {
                // Check if room number already exists
                if (Room::exists($room_number)) { // Add this static method to Room class
                    $error = "Room number already exists.";
                } else {
                    // Add new room
                    $room = new Room(null, $room_number, $type, $price, $status);
                    $room->save();
                    $success = "Room added successfully.";
                }
            } elseif ($action == 'edit') {
                $room_id = $_POST['room_id'] ?? '';
                // Check if room number already exists for another room
                if (Room::exists($room_number, $room_id)) { // Add this static method to Room class
                    $error = "Room number already exists.";
                } else {
                    // Update room
                    $room = Room::find($room_id); // Update find method to return Room object
                    $room->setRoomNumber($room_number);
                    $room->setType($type);
                    $room->setPrice($price);
                    $room->setStatus($status);
                    $room->save();
                    $success = "Room updated successfully.";
                }
            }
            if ($success) {
                header("Location: admin_dashboard.php?success=" . urlencode($success));
                exit();
            }
        } catch (Exception $e) {
            $error = "Error saving room: " . $e->getMessage();
        }
    }
}

// Handle Delete Room
if (isset($_GET['delete_id'])) {
    $room_id = $_GET['delete_id'];
    try {
        $room = Room::find($room_id);
        if ($room->hasActiveBookings()) { // Add this method to Room class
            $error = "Cannot delete room with active bookings.";
        } else {
            $room->delete(); // Add this method to Room class
            $success = "Room deleted successfully.";
        }
    } catch (Exception $e) {
        $error = "Error deleting room: " . $e->getMessage();
    }
    if ($success || $error) {
        header("Location: admin_dashboard.php?success=" . urlencode($success) . "&error=" . urlencode($error));
        exit();
    }
}

// Fetch room for editing
$edit_room = null;
if (isset($_GET['edit_id'])) {
    try {
        $edit_room = Room::find($_GET['edit_id']); // Update to return Room object
    } catch (Exception $e) {
        $error = "Error fetching room: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Manage Rooms</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <?php if (isset($_GET['success'])): ?>
            <div class="success">
                <p><?php echo htmlspecialchars($_GET['success']); ?></p>
            </div>
        <?php elseif ($error): ?>
            <div class="error">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php endif; ?>
        <div class="card">
            <h2><?php echo $edit_room ? 'Edit Room' : 'Add New Room'; ?></h2>
            <form method="POST">
                <input type="hidden" name="action" value="<?php echo $edit_room ? 'edit' : 'add'; ?>">
                <?php if ($edit_room): ?>
                    <input type="hidden" name="room_id" value="<?php echo htmlspecialchars($edit_room->getId()); ?>">
                <?php endif; ?>
                <label for="room_number">Room Number</label>
                <input type="number" id="room_number" name="room_number" value="<?php echo htmlspecialchars($edit_room ? $edit_room->getRoomNumber() : ''); ?>" required>
                <label for="type">Room Type</label>
                <select id="type" name="type" required>
            <?php
            $types = ['Single', 'Double', 'Deluxe', 'Suite', 'Executive'];
            $selectedType = $edit_room ? $edit_room->getType() : '';
            foreach ($types as $type) {
                  $selected = $selectedType === $type ? 'selected' : '';
                echo "<option value=\"$type\" $selected>$type</option>";
              }
            ?>
        </select>
                <label for="price">Price per Night (PKR)</label>
                <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($edit_room ? $edit_room->getPrice() : ''); ?>" required>
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    <option value="Available" <?php echo ($edit_room && $edit_room->getStatus() == 'Available') ? 'selected' : ''; ?>>Available</option>
                    <option value="Booked" <?php echo ($edit_room && $edit_room->getStatus() == 'Booked') ? 'selected' : ''; ?>>Booked</option>
                    <option value="Under Maintenance" <?php echo ($edit_room && $edit_room->getStatus() == 'Under Maintenance') ? 'selected' : ''; ?>>Under Maintenance</option>
                </select>
                <button type="submit"><?php echo $edit_room ? 'Update Room' : 'Add Room'; ?></button>
            </form>
        </div>
        <div class="card">
            <h2>All Rooms</h2>
            <?php if (empty($rooms)): ?>
                <p>No rooms found. Add a new room above.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Room Number</th>
                            <th>Type</th>
                            <th>Price (PKR)</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rooms as $room): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($room->getRoomNumber()); ?></td>
                                <td><?php echo htmlspecialchars($room->getType()); ?></td>
                                <td><?php echo htmlspecialchars($room->getPrice()); ?></td>
                                <td><?php echo htmlspecialchars($room->getStatus()); ?></td>
                                <td>
                                    <a href="manage_rooms.php?edit_id=<?php echo $room->getId(); ?>">Edit</a> |
                                    <a href="manage_rooms.php?delete_id=<?php echo $room->getId(); ?>" onclick="return confirm('Are you sure you want to delete this room?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>