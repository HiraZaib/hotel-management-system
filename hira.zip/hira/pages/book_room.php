<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Room.php';
require_once '../includes/classes/Booking.php';
require_once '../includes/classes/SystemUsers.php';
require_once '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Guest') {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

$success = '';
$error = '';
$available_rooms = [];

try {
    $available_rooms = Room::getAvailable();
} catch (Exception $e) {
    $error = "Error fetching rooms: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $room_id = $_POST['room_id'] ?? '';
    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';

    $today = date('Y-m-d');
    $check_in_date = DateTime::createFromFormat('Y-m-d', $check_in);
    $check_out_date = DateTime::createFromFormat('Y-m-d', $check_out);

    if (!$check_in_date || !$check_out_date) {
        $error = "Invalid date format.";
    } elseif ($check_in < $today) {
        $error = "Check-in date cannot be in the past.";
    } elseif ($check_out <= $check_in) {
        $error = "Check-out date must be after check-in date.";
    } else {
        if (!Booking::isRoomAvailable($room_id, $check_in, $check_out)) {
            $error = "The selected room is not available for the chosen dates.";
        } else {
            $room = Room::find($room_id);
            $days = $check_out_date->diff($check_in_date)->days;
            $total_price = $days * $room->getPrice();

            $user = SystemUsers::find($_SESSION['user_id']);
            if (!$user) {
                $error = "User data not found.";
            } else {
                $booking = new Booking();
                $booking->setSystemUserId($user->getId());
                $booking->setEmail($user->getEmail());
                $booking->setUsername($user->getUsername());
                $booking->setRoomId($room_id);
                $booking->setCheckIn($check_in);
                $booking->setCheckOut($check_out);
                $booking->setTotalPrice($total_price);
                $booking->setRoomNumber($room->getRoomNumber()); // Set room number
                $booking->setRoomPrice($room->getPrice());        // Set room price
                $booking->setStatus('Pending');

                try {
                    if ($booking->save()) {
                        $booking_id = $conn->lastInsertId();

                        $mail = new PHPMailer(true);
                        try {
                            $mail->isSMTP();
                            $mail->Host = 'smtp.gmail.com';
                            $mail->SMTPAuth = true;
                            $mail->Username = 'hirazaib939@gmail.com';
                            $mail->Password = 'rqxrarcmvdevwlmz'; // Use env variable in production
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                            $mail->Port = 587;

                            $mail->setFrom('hirazaib939@gmail.com', 'HA Aura');
                            $mail->addAddress($user->getEmail(), $user->getUserName());

                            $mail->isHTML(true);
                            $mail->Subject = 'Booking Confirmation - HA Aura';
                            $mail->Body = "Dear {$user->getUserName()},<br><br>
                                           Your booking (ID: $booking_id) for Room {$room->getRoomNumber()} has been successfully confirmed.<br>
                                           <strong>Details:</strong><br>
                                           Check-In: $check_in<br>
                                           Check-Out: $check_out<br>
                                           Total Price: PKR $total_price<br><br>
                                           We look forward to welcoming you!<br><br>
                                           Best regards,<br>HA Aura";

                            $mail->AltBody = "Dear {$user->getUserName()},\n\n
                                              Your booking (ID: $booking_id) for Room {$room->getRoomNumber()} has been successfully confirmed.\n
                                              Check-In: $check_in\n
                                              Check-Out: $check_out\n
                                              Total Price: PKR $total_price\n\n
                                              Best regards,\nHA Aura";

                            $mail->send();
                        } catch (Exception $e) {
                            $error .= " Email failed: {$mail->ErrorInfo}.";
                        }

                        $success = "Booking confirmed successfully (Booking ID: $booking_id).";
                    } else {
                        $error = "Error saving booking.";
                    }
                } catch (Exception $e) {
                    $error = "Exception: " . $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HA Aura - Book a Room</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<div class="container">
    <div class="card">
        <h2>Book a Room</h2>
        <?php if ($success): ?>
            <div class="success">
                <p><?php echo htmlspecialchars($success); ?></p>
                <a href="<?php echo BASE_URL; ?>pages/guest_dashboard.php">Return to Dashboard</a>
            </div>
        <?php elseif ($error): ?>
            <div class="error">
                <p><?php echo htmlspecialchars($error); ?></p>
            </div>
        <?php else: ?>
            <form method="POST">
                <label for="room_id">Select Room</label>
                <select id="room_id" name="room_id" required>
                    <option value="">-- Select a Room --</option>
                    <?php foreach ($available_rooms as $room): ?>
                        <option value="<?php echo htmlspecialchars($room->getId()); ?>">
                            <?php echo htmlspecialchars("Room {$room->getRoomNumber()} ({$room->getType()}) - PKR {$room->getPrice()}/night"); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="check_in">Check-In Date</label>
                <input type="date" name="check_in" value="<?php echo date('Y-m-d'); ?>" required>
                <label for="check_out">Check-Out Date</label>
                <input type="date" name="check_out" value="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                <button type="submit">Book Room</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
</body>
</html>
