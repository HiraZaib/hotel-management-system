<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/SystemUsers.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $selected_role = $_POST['role'] ?? '';

    // Authenticate user using SystemUsers class
    $user = SystemUsers::findByUsername($username); // Add this static method to SystemUsers class

    if ($user && password_verify($password, $user->getPassword())) {
        // Validate selected role matches stored role
        if ($selected_role && $selected_role === $user->getRole()) {
            $_SESSION['user_id'] = $user->getId();
            $_SESSION['username'] = $user->getUsername();
            $_SESSION['role'] = $user->getRole();

            // Redirect to appropriate dashboard based on role
            switch ($user->getRole()) {
        case 'Guest':
            header("Location: " . BASE_URL . "pages/guest_dashboard.php");
            break;
        case 'Staff':
            header("Location: " . BASE_URL . "pages/staff_dashboard.php");
            break;
        case 'Admin':
            header("Location: " . BASE_URL . "pages/admin_dashboard.php");
            break;
        default:
            echo "<p class='error'>Invalid role.</p>";
            break;
    }
            
            exit();
        } else {
            echo "<p class='error'>Selected role does not match your account.</p>";
        }
    } else {
        echo "<p class='error'>Invalid username or password.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container">
        <div class="card">
            <h2>Login</h2>
            <form method="POST">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="">Select Role</option>
                    <option value="Guest">Guest</option>
                    <option value="Staff">Staff</option>
                    <option value="Admin">Admin</option>
                </select>
                <button type="submit">Login</button>
            </form>
            
            <p><a href="forgot_password.php" class="forget">Forgot Password?</a></p>
            <p>Don't have an account? <a href="register.php">Register</a></p>
        </div>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>