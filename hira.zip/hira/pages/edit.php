<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
$success = "";
$error = "";

// Fetch current user data
$stmt = $conn->prepare("SELECT email, username FROM system_users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$currentEmail = $user['email'];
$currentUsername = $user['username'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['edit_email'])) {
        $newEmail = trim($_POST['email']);
        if (filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $check = $conn->prepare("SELECT id FROM system_users WHERE email = ? AND id != ?");
            $check->execute([$newEmail, $userId]);
            if ($check->rowCount() > 0) {
                $error = "Email is already in use by another account.";
            } else {
                $stmt = $conn->prepare("UPDATE system_users SET email = ? WHERE id = ?");
                if ($stmt->execute([$newEmail, $userId])) {
                    $success = "Email updated successfully.";
                    $currentEmail = $newEmail;
                } else {
                    $error = "Failed to update email.";
                }
            }
        } else {
            $error = "Invalid email format.";
        }
    }

    if (isset($_POST['edit_username'])) {
        $newUsername = trim($_POST['username']);
        if (!empty($newUsername)) {
            $check = $conn->prepare("SELECT id FROM system_users WHERE username = ? AND id != ?");
            $check->execute([$newUsername, $userId]);
            if ($check->rowCount() > 0) {
                $error = "Username is already taken.";
            } else {
                $stmt = $conn->prepare("UPDATE system_users SET username = ? WHERE id = ?");
                if ($stmt->execute([$newUsername, $userId])) {
                    $success = "Username updated successfully.";
                    $_SESSION['username'] = $newUsername;
                    $currentUsername = $newUsername;
                } else {
                    $error = "Failed to update username.";
                }
            }
        } else {
            $error = "Username cannot be empty.";
        }
    }

    if (isset($_POST['edit_password'])) {
        $newPassword = $_POST['password'];
        $confirm = $_POST['confirm_password'];
        if ($newPassword === $confirm && strlen($newPassword) >= 6) {
            $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE system_users SET password = ? WHERE id = ?");
            if ($stmt->execute([$hashed, $userId])) {
                $success = "Password updated successfully.";
            } else {
                $error = "Failed to update password.";
            }
        } else {
            $error = "Passwords must match and be at least 6 characters.";
        }
    }

  
}
?>

<?php include '../includes/header.php'; ?>

<div class="container py-4">
    <h2 class="text-center mb-4">Manage Your Account</h2>

    <?php if ($success): ?>
        <div class="success"><?php echo $success; ?></div>
    <?php elseif ($error): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-md-8">

            <!-- Edit Email -->
            <form method="POST" class="card p-4 mb-4">
                <h3>Edit Email</h3>
                <input type="email" name="email" class="form-control mb-2" value="<?php echo htmlspecialchars($currentEmail); ?>" required>
                <button type="submit" name="edit_email" class="book-now-btn">Update Email</button>
            </form>

            <!-- Edit Username -->
            <form method="POST" class="card p-4 mb-4">
                <h3>Edit Username</h3>
                <input type="text" name="username" class="form-control mb-2" value="<?php echo htmlspecialchars($currentUsername); ?>" required>
                <button type="submit" name="edit_username" class="book-now-btn">Update Username</button>
            </form>

            <!-- Edit Password -->
            <form method="POST" class="card p-4 mb-4">
                <h3>Change Password</h3>
                <input type="password" name="password" class="form-control mb-2" placeholder="New password" required>
                <input type="password" name="confirm_password" class="form-control mb-2" placeholder="Confirm password" required>
                <button type="submit" name="edit_password" class="book-now-btn">Update Password</button>
            </form>

            

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
