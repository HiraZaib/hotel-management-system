<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';

// Restrict access to Guest role only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Guest') {
    header("Location: login.php");
    exit();
}

// Fetch user's bookings using Booking class
$system_user_id = $_SESSION['user_id']; // assuming this is from system_users table
$bookings = Booking::getBookingsBySystemUserId($system_user_id);


// Helper function to format dates
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

// Helper function to get status badge class
function getStatusClass($status) {
    switch (strtolower($status)) {
        case 'confirmed':
            return 'status-confirmed';
        case 'pending':
            return 'status-pending';
        case 'cancelled':
            return 'status-cancelled';
        case 'completed':
            return 'status-completed';
        default:
            return 'status-default';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HA Aura - Guest Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <h1 class="welcome-text">Welcome back, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Guest'); ?>!</h1>
            <p>Manage your bookings and explore our hotel services</p>
        </div>

        <!-- Success/Error Messages -->
        <?php if (isset($_GET['success'])): ?>
            <div class="success">
                <p><?php echo htmlspecialchars($_GET['success']); ?></p>
            </div>
        <?php elseif (isset($_GET['error'])): ?>
            <div class="error">
                <p><?php echo htmlspecialchars($_GET['error']); ?></p>
            </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <?php 
        $totalBookings = count($bookings);
        $confirmedBookings = count(array_filter($bookings, function($b) { return $b->getStatus() == 'Confirmed'; }));
        $pendingBookings = count(array_filter($bookings, function($b) { return $b->getStatus() == 'Pending'; }));
        $totalSpent = array_sum(array_map(function($b) { return $b->getTotalPrice(); }, $bookings));
        ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $totalBookings; ?></div>
                <div class="stat-label">Total Bookings</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $confirmedBookings; ?></div>
                <div class="stat-label">Confirmed Bookings</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $pendingBookings; ?></div>
                <div class="stat-label">Pending Bookings</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">PKR <?php echo number_format($totalSpent); ?></div>
                <div class="stat-label">Total Spent</div>
            </div>
        </div>

        <!-- Bookings Table -->
        <div class="bookings-table">
            <div class="table-header">
                <h2>Your Bookings</h2>
            </div>
            
            <?php if (empty($bookings)): ?>
                <div class="empty-state">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🏨</div>
                    <h3>No bookings yet</h3>
                    <p>Start your journey with us by booking your first room!</p>
                    <a href="<?php echo BASE_URL; ?>pages/book_room.php" class="book-now-btn">Book a Room Now</a>
                </div>
            <?php else: ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
">
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Booking ID</th>
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Room</th>
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Check-In</th>
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Check-Out</th>
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Total Price</th>
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Status</th>
                                <th style="padding: 1rem; text-align: left; border-bottom: 1px solid #e9ecef;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr style="border-bottom: 1px solid #f8f9fa;">
                                    <td style="padding: 1rem;">#<?php echo htmlspecialchars($booking->getId()); ?></td>
                                    <td style="padding: 1rem;">Room <?php echo htmlspecialchars($booking->getRoomNumber()); ?></td>
                                    <td style="padding: 1rem;"><?php echo formatDate($booking->getCheckIn()); ?></td>
                                    <td style="padding: 1rem;"><?php echo formatDate($booking->getCheckOut()); ?></td>
                                    <td style="padding: 1rem;">PKR <?php echo number_format($booking->getTotalPrice()); ?></td>
                                    <td style="padding: 1rem;">
                                        <span class="status-badge <?php echo getStatusClass($booking->getStatus()); ?>">
                                            <?php echo htmlspecialchars($booking->getStatus()); ?>
                                        </span>
                                    </td>
                                    <td style="padding: 1rem;">
                                        <?php if ($booking->getStatus() == 'Confirmed'): ?>
                                            <div class="action-buttons">
                                                <a href="<?php echo BASE_URL; ?>pages/modify_booking.php?id=<?php echo $booking->getId(); ?>" class="btn-small btn-modify">Modify</a>
                                                <a href="<?php echo BASE_URL; ?>pages/cancel_booking.php?id=<?php echo $booking->getId(); ?>" class="btn-small btn-cancel" onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel</a>
                                            </div>
                                        <?php elseif ($booking->getStatus() == 'Pending'): ?>
                                            <span style="color: #666; font-size: 0.9rem;">Awaiting confirmation</span>
                                        <?php else: ?>
                                            <span style="color: #999; font-size: 0.9rem;">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="padding: 1rem; text-align: center; background: #f8f9fa;">
                    <a href="<?php echo BASE_URL; ?>pages/book_room.php" class="book-now-btn">Book Another Room</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../includes/footer.php'; ?>
</body>
</html>