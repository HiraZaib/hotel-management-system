<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/classes/Booking.php';
require_once '../includes/classes/SystemUsers.php';
require_once '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Guest') {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

$booking_id = $_GET['id'] ?? null;
$success = '';
$error = '';
$booking = null;

// Fetch booking details
if ($booking_id) {
    try {
        $booking = Booking::findByIdAndUserId($booking_id, $_SESSION['user_id']); // Add this method in Booking class
        if (!$booking) {
            $error = "Booking not found or unauthorized access.";
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $booking) {
    $new_check_in = $_POST['check_in'] ?? '';
    $new_check_out = $_POST['check_out'] ?? '';

    $today = date('Y-m-d');
    $check_in_date = DateTime::createFromFormat('Y-m-d', $new_check_in);
    $check_out_date = DateTime::createFromFormat('Y-m-d', $new_check_out);

    if (!$check_in_date || !$check_out_date) {
        $error = "Invalid date format.";
    } elseif ($new_check_in < $today) {
        $error = "Check-in date cannot be in the past.";
    } elseif ($new_check_out <= $new_check_in) {
        $error = "Check-out must be after check-in.";
    } elseif ($booking->getStatus() !== 'Confirmed') {
        $error = "Only confirmed bookings can be modified.";
    } elseif (!Booking::isRoomAvailable($booking->getRoomId(), $new_check_in, $new_check_out, $booking->getId())) {
        $error = "The room is not available for the selected dates.";
    } else {
        // Update and save booking
        $days = $check_out_date->diff($check_in_date)->days;
        $new_total_price = $days * $booking->getRoomPrice();

        $booking->setCheckIn($new_check_in);
        $booking->setCheckOut($new_check_out);
        $booking->setTotalPrice($new_total_price);
        $booking->setRoomPrice($booking->getRoomPrice()); // Keep price accurate

        try {
            $booking->save();

            $user = SystemUsers::find($_SESSION['user_id']);
            if (!$user) {
                $error = "User not found.";
            } else {
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'hirazaib939@gmail.com';
                    $mail->Password = 'rqxrarcmvdevwlmz'; // Use env variable ideally
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('hirazaib939@gmail.com', 'HA Aura');
                    $mail->addAddress($user->getEmail(), $user->getUserName());

                    $mail->isHTML(true);
                    $mail->Subject = 'Booking Modification Confirmation - HA Aura';
                    $mail->Body = "Dear {$user->getUserName()},<br><br>
                                   Your booking (ID: {$booking->getId()}) for Room {$booking->getRoomNumber()} has been successfully modified.<br>
                                   <strong>New Details:</strong><br>
                                   Check-In: $new_check_in<br>
                                   Check-Out: $new_check_out<br>
                                   Total Price: PKR $new_total_price<br><br>
                                   We look forward to welcoming you!<br><br>
                                   Best regards,<br>HA Aura";

                    $mail->AltBody = "Dear {$user->getUserName()},\n\n
                                      Your booking (ID: {$booking->getId()}) for Room {$booking->getRoomNumber()} has been successfully modified.\n
                                      Check-In: $new_check_in\n
                                      Check-Out: $new_check_out\n
                                      Total Price: PKR $new_total_price\n\n
                                      Best regards,\nHA Aura";

                    $mail->send();
                } catch (Exception $e) {
                    $error .= " Email error: {$mail->ErrorInfo}.";
                }

                $success = "Booking modified successfully.";
            }
        } catch (Exception $e) {
            $error = "Error updating booking: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HA Aura - Modify Booking</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<div class="container">
    <div class="card">
        <h2>Modify Booking</h2>
        <?php if ($success): ?>
            <div class="success">
                <p><?php echo htmlspecialchars($success); ?></p>
                <a href="<?php echo BASE_URL; ?>pages/guest_dashboard.php">Return to Dashboard</a>
            </div>
        <?php elseif ($error): ?>
            <div class="error">
                <p><?php echo htmlspecialchars($error); ?></p>
                <a href="<?php echo BASE_URL; ?>pages/guest_dashboard.php">Return to Dashboard</a>
            </div>
        <?php elseif ($booking): ?>
            <form method="POST">
                <label for="check_in">Check-In Date</label>
                <input type="date" name="check_in" value="<?php echo htmlspecialchars($booking->getCheckIn()); ?>" required>

                <label for="check_out">Check-Out Date</label>
                <input type="date" name="check_out" value="<?php echo htmlspecialchars($booking->getCheckOut()); ?>" required>

                <p><strong>Current Price per Night:</strong> PKR <?php echo htmlspecialchars($booking->getRoomPrice()); ?></p>
                <p><strong>Old Total Price:</strong> PKR <?php echo htmlspecialchars($booking->getTotalPrice()); ?></p>

                <button type="submit">Modify Booking</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php include '../includes/footer.php'; ?>
</body>
</html>
